Solstice Ultra

The most detailed standard pack: 4096 shadows, aurora nights, detailed waves and a wide glow. Needs a strong GPU.

Install: put the .zip (do not unzip) in .minecraft/shaderpacks, then pick it in Video Settings > Shaders. Needs Iris or OptiFine.
Most options can also be changed in-game under Shader Options.
