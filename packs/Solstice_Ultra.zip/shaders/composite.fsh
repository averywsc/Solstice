#version 120
#define SKY_CLOUDS 1
#define CLOUD_OCT 5
#define SKY_CIRRUS 1
#define SKY_STARS 2
#define SKY_AURORA 1
#define SKY_TINT vec3(1.0, 1.0, 1.0)
#define SKY_VIVID 0
#define MOON_DETAIL 1
#define SUN_STRENGTH 0.8
#define SUN_COLOR vec3(1.0, 1.0, 1.0)
#define MOON_STRENGTH 1.0
#define AMB_STRENGTH 1.0
#define AMB_SAT 0.65
#define BOUNCE_STRENGTH 1.0
#define TORCH_STRENGTH 1.0
#define TORCH_NEAR vec3(1.0, 0.5, 0.16)
#define TORCH_FAR vec3(1.0, 0.22, 0.04)
#define EMISSIVE_STRENGTH 0.65
#define RIM_STRENGTH 1.0
#define FOLIAGE_GLOW 1.0
#define BLOCK_VARIATION 1.0
#define HELD_LIGHT 1.0
#define SHINY_STRENGTH 1.0
#define WET_STRENGTH 1.0
#define SHADOWS 2
#define SHADOW_TAPS 20
#define SHADOW_RAD 2.2
#define CLOUD_SHADOWS 1
#define FOG_DENSITY 0.0009
#define VOL_LIGHT
#define VOL_STEPS 12
#define VOL_RANGE 96
#define VOL_DENSITY 0.012
#define VOL_STRENGTH 1.0
#define WAVES_EXTRA 1
#define WATER_NORMALS 1
#define WATER_COL vec3(0.039, 0.165, 0.184)
#define WATER_SPEC 9.0
#define SSR
#define SSR_STEPS 28
#define SWAY_PLANT 0.06
#define SWAY_LEAF 0.025
#define AO_TAPS 12
#define AO_STRENGTH 0.6
#define SSL_TAPS 16
#define SSL_STRENGTH 9.0
#define SSL_RADIUS 8.0
#define GI_TAPS 16
#define GI_STRENGTH 2.0
#define GI_RADIUS 5.0
#define DOF_TAPS 2
#define DOF_STRENGTH 1.2
#define DOF_RADIUS 0.01
#define MB_STRENGTH 0.6
#define MB_MAX 0.03
#define BLOOM_TAPS 40
#define BLOOM_STRENGTH 0.3
#define BLOOM_RADIUS 0.03
#define BLOOM_THRESH 3.0
#define GODRAYS
#define GODRAY_STEPS 24
#define GODRAY_STRENGTH 0.3
#define FLARE
#define FLARE_STRENGTH 0.08
#define EXPOSURE 0.36
#define AUTO_EXPOSURE
#define SAT 0.95
#define VIBRANCE 0.08
#define CONTRAST 0.15
#define VIGN 0.4
#define SHADOW_TINT vec3(1.0)
#define HIGH_TINT vec3(1.0)
#define GRADE_AMT 0.0
#define LIFT 0.0
#define LIFT_COL vec3(0.2, 0.18, 0.2)
#define SHARPEN_ON
#define SHARPEN 0.3
#define FXAA_ON
#define GBUF_ON
#ifndef SKY_TINT
#define SKY_TINT vec3(1.0)
#endif
#ifndef FOG_DENSITY
#define FOG_DENSITY 0.0009
#endif
#ifndef VOL_STEPS
#define VOL_STEPS 8
#endif
#ifndef VOL_RANGE
#define VOL_RANGE 80
#endif
#ifndef VOL_DENSITY
#define VOL_DENSITY 0.012
#endif
#ifndef VOL_STRENGTH
#define VOL_STRENGTH 1.0
#endif
#ifndef SSR_STEPS
#define SSR_STEPS 24
#endif
/* const int colortex0Format = RGBA16F; */
const vec4 colortex1ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex2ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex3ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex4ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
varying vec2 texcoord;
uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
#ifdef VOL_LIGHT
uniform sampler2D shadowtex1;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 shadowLightPosition;
uniform int moonPhase;
#endif
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjection;
uniform float frameTimeCounter;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float far;
uniform float rainStrength;
uniform int isEyeInWater;
uniform ivec2 eyeBrightnessSmooth;

const vec3 BR = vec3(5.8e-3, 13.5e-3, 33.1e-3);
const float BM = 0.01;
const vec3 BO = vec3(0.65e-3, 1.881e-3, 0.085e-3);
vec3 twilightFill(float h, float cs, float sh) {
    float e = (sh + 0.06) / 0.10;
    float tw = exp(-e * e);
    float side = 0.35 + 0.65 * pow(max(cs, 0.0), 2.0);
    float hz = pow(1.0 - clamp(abs(h), 0.0, 1.0), 3.0);
    vec3 c = mix(vec3(0.07, 0.1, 0.28), vec3(0.95, 0.38, 0.48), hz * side);
    return c * tw * 0.35;
}
vec3 sunTrans(float sh) {
    if (sh < 0.0) return vec3(0.0);
    float R = 6371.0;
    float alt0 = 0.002;
    float sx = sqrt(max(1.0 - sh * sh, 0.0));
    float b = (R + alt0) * sh;
    float tl = -b + sqrt(b * b + (100.0 - alt0) * (2.0 * R + 100.0 + alt0));
    float odr = 0.0; float odm = 0.0; float odo = 0.0;
    for (int j = 0; j < 8; j++) {
        float u = (float(j) + 0.5) / 8.0;
        float d = tl * u * u;
        float w = tl * 2.0 * u / 8.0;
        vec3 Q = vec3(sx * d, R + alt0 + sh * d, 0.0);
        float a = max(length(Q) - R, 0.0);
        odr += exp(-a / 8.0) * w;
        odm += exp(-a / 1.2) * w;
        odo += max(0.0, 1.0 - abs(a - 25.0) / 15.0) * w;
    }
    return exp(-(BR * odr + BM * 1.1 * odm + BO * odo));
}
float effSh(float sh) {
    return sh < 0.0 ? sh : mix(sh * 0.08, sh, smoothstep(0.30, 0.75, sh));
}
float goldF(float shR) {
    return (1.0 - smoothstep(0.15, 0.6, shR)) * smoothstep(-0.05, 0.08, shR);
}
vec3 goldTint(float shR) {
    return mix(vec3(1.0), vec3(1.12, 0.92, 0.64), goldF(shR));
}
vec3 goldenFill(float h, float cs, float shR) {
    float gw = smoothstep(0.0, 0.08, shR) * (1.0 - smoothstep(0.15, 0.6, shR)) * 2.0;
    float hz = pow(1.0 - clamp(abs(h), 0.0, 1.0), 3.0);
    vec3 c = mix(vec3(0.34, 0.16, 0.09), vec3(1.7, 0.75, 0.3), hz);
    return c * gw * (0.4 + 0.6 * pow(max(cs, 0.0), 2.0));
}
vec3 sunLight(float shR) {
    float g = goldF(shR);
    vec3 neutral = sunTrans(shR) * 3.4;
    vec3 golden = vec3(3.4, 1.05, 0.32) * smoothstep(0.0, 0.06, shR);
    return mix(neutral, golden, g);
}

vec3 skyF(vec3 dir, vec3 sunDir, vec3 upN) {
    float shR = dot(sunDir, upN);
    if (shR < -0.32) return vec3(0.0);
    float sh = effSh(shR);
    float h = max(dot(dir, upN), 0.0005);
    float cs = clamp(dot(dir, sunDir), -1.0, 1.0);
    float vx = sqrt(max(1.0 - h * h, 0.0));
    float sx = (cs - h * sh) / max(vx, 0.0001);
    float sz = sqrt(max(1.0 - sh * sh - sx * sx, 0.0));
    float R = 6371.0;
    float alt0 = 0.002;
    float b = (R + alt0) * h;
    float tm = min(-b + sqrt(b * b + (100.0 - alt0) * (2.0 * R + 100.0 + alt0)), 40.0);
    float ds = tm / float(6);
    float odr = 0.0; float odm = 0.0; float odo = 0.0;
    vec3 sc = vec3(0.0);
    float pr = 0.0596831 * (1.0 + cs * cs) * 1.4;
    float pm = 0.119366 * (0.36 * (1.0 + cs * cs)) / (2.64 * pow(1.64 - 1.6 * cs, 1.5));
    for (int i = 0; i < 6; i++) {
        float t = ds * (float(i) + 0.5);
        float px = vx * t;
        float py = R + alt0 + h * t;
        float len = sqrt(px * px + py * py);
        float alt = (px * px + (alt0 + h * t) * (2.0 * R + alt0 + h * t)) / (len + R);
        float dr = exp(-alt / 8.0);
        float dm = exp(-alt / 1.2);
        float dzo = max(0.0, 1.0 - abs(alt - 25.0) / 15.0);
        odr += dr * ds; odm += dm * ds; odo += dzo * ds;
        float b2 = px * sx + py * sh;
        if (b2 < 0.0 && b2 * b2 - alt * (len + R) > 0.0) continue;
        float tl = -b2 + sqrt(max(b2 * b2 - (alt - 100.0) * (len + 6471.0), 0.0));
        float lr = 0.0; float lm = 0.0; float lo = 0.0;
        for (int j = 0; j < 3; j++) {
            float u = (float(j) + 0.5) / float(3);
            float d = tl * u * u;
            float w = tl * 2.0 * u / float(3);
            vec3 Q = vec3(px + sx * d, py + sh * d, sz * d);
            float a = max(length(Q) - R, 0.0);
            lr += exp(-a / 8.0) * w;
            lm += exp(-a / 1.2) * w;
            lo += max(0.0, 1.0 - abs(a - 25.0) / 15.0) * w;
        }
        vec3 att = exp(-(BR * (odr + lr) + BM * 1.1 * (odm + lm) + BO * (odo + lo)));
        sc += att * (BR * dr * pr + BM * dm * pm) * ds;
    }
    vec3 outc = (sc * 22.0 + twilightFill(h, cs, shR) + goldenFill(h, cs, shR)) * goldTint(shR);
    outc.g = min(outc.g, max(outc.r, outc.b) * 1.04);
    return outc * SKY_TINT;
}

float hash21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vnoise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash21(i), hash21(i + vec2(1.0, 0.0)), f.x), mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), f.x), f.y);
}
vec3 vpAtD(vec2 uv, float d) {
    vec4 p = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);
    return p.xyz / p.w;
}
#ifdef VOL_LIGHT
float volAcc(vec3 feetDir, float maxD) {
    float ign = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    float acc = 0.0;
    for (int i = 0; i < VOL_STEPS; i++) {
        float t = (float(i) + ign) / float(VOL_STEPS);
        vec3 pf = feetDir * (t * maxD);
        vec4 sp = shadowProjection * (shadowModelView * vec4(pf, 1.0));
        sp.xy /= length(sp.xy) * 0.9 + 0.1;
        vec3 sc = sp.xyz * 0.5 + 0.5;
        float lit = 1.0;
        if (sc.x > 0.0 && sc.x < 1.0 && sc.y > 0.0 && sc.y < 1.0 && sc.z < 1.0)
            lit = step(sc.z - 0.0008, texture2D(shadowtex1, sc.xy).r);
        acc += lit * (0.7 + 0.6 * vnoise(pf.xz * 0.25 + pf.y * 0.1 + frameTimeCounter * 0.08));
    }
    return acc / float(VOL_STEPS);
}
#endif
void main() {
    vec3 col = texture2D(colortex0, texcoord).rgb;
    float d = texture2D(depthtex0, texcoord).r;
    vec4 p = gbufferProjectionInverse * vec4(texcoord * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);
    vec3 vpos = p.xyz / p.w;
    float dist = length(vpos);
    vec3 dir = vpos / dist;
    vec3 upN = normalize(upPosition);
    vec3 sunDir = normalize(sunPosition);
    float sunH = dot(sunDir, upN);

    if (isEyeInWater == 1) {
        float f = 1.0 - exp(-dist * 0.09);
        vec3 wc = vec3(0.02, 0.2, 0.3) * (0.25 + 0.75 * float(eyeBrightnessSmooth.y) / 240.0);
        col = mix(col * vec3(0.55, 0.85, 1.0), wc, f);
#ifdef VOL_LIGHT
        {
            vec3 feetDirU = mat3(gbufferModelViewInverse) * dir;
            float maxDU = d < 1.0 ? min(dist, 36.0) : 36.0;
            float accU = volAcc(feetDirU, maxDU);
            vec3 lightU = (sunH > 0.0 ? sunLight(sunH) : vec3(0.35, 0.5, 0.9) * 0.35) * smoothstep(0.0, 0.05, abs(sunH));
            float skyFU = float(eyeBrightnessSmooth.y) / 240.0;
            float csU = dot(dir, normalize(shadowLightPosition));
            float phU = 0.15 + 0.85 * pow(max(csU, 0.0), 3.0);
            col += lightU * vec3(0.12, 0.45, 0.55) * phU * accU * (1.0 - exp(-maxDU * 0.07)) * skyFU * 1.4;
        }
#endif
    } else if (isEyeInWater == 2) {
        float f = 1.0 - exp(-dist * 0.8);
        col = mix(col, vec3(0.9, 0.25, 0.02), f);
    } else {
        vec4 wm = texture2D(colortex1, texcoord);
        if (wm.r > 0.5) {
#ifdef SSR
            {
                vec2 nxy = wm.gb * 2.0 - 1.0;
                vec3 nV = vec3(nxy, sqrt(max(1.0 - dot(nxy, nxy), 0.0)));
                vec3 Vd = normalize(vpos);
                vec3 Rr = reflect(Vd, nV);
                float ndv = max(dot(nV, -Vd), 0.0);
                float Fr = 0.02 + 0.98 * pow(1.0 - ndv, 5.0);
                vec3 pos = vpos + nV * 0.05;
                float stepL = 0.5;
                float hit = 0.0;
                vec3 hitCol = vec3(0.0);
                vec2 huv = vec2(0.5);
                float jit = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
                pos += Rr * stepL * jit;
                for (int i = 0; i < SSR_STEPS; i++) {
                    pos += Rr * stepL;
                    stepL *= 1.15;
                    vec4 pc = gbufferProjection * vec4(pos, 1.0);
                    if (pc.w <= 0.0) break;
                    vec2 uvr = pc.xy / pc.w * 0.5 + 0.5;
                    if (uvr.x < 0.0 || uvr.x > 1.0 || uvr.y < 0.0 || uvr.y > 1.0) break;
                    float ds = texture2D(depthtex1, uvr).r;
                    if (ds >= 1.0) continue;
                    vec3 sp = vpAtD(uvr, ds);
                    float diff = (-pos.z) - (-sp.z);
                    if (diff > 0.0 && diff < stepL * 1.2 + 0.2) { hit = 1.0; huv = uvr; hitCol = texture2D(colortex0, uvr).rgb; break; }
                }
                float ef = smoothstep(0.0, 0.1, min(min(huv.x, 1.0 - huv.x), min(huv.y, 1.0 - huv.y)));
                col = mix(col, hitCol, Fr * hit * ef);
            }
#endif
            float d1 = texture2D(depthtex1, texcoord).r;
            vec4 p1 = gbufferProjectionInverse * vec4(texcoord * 2.0 - 1.0, d1 * 2.0 - 1.0, 1.0);
            float thick = min(max(length(p1.xyz / p1.w) - dist, 0.0), 60.0);
            vec3 T = exp(-thick * vec3(0.35, 0.07, 0.04));
            vec3 ambW = skyF(upN, sunDir, upN) + vec3(0.004, 0.006, 0.014);
            vec3 irr = ambW + sunLight(sunH) * 0.2 * max(sunH, 0.0);
            col = col * T + vec3(0.03, 0.14, 0.17) * irr * (1.0 - exp(-thick * 0.18));
            vec3 wp = (gbufferModelViewInverse * vec4(vpos, 1.0)).xyz + cameraPosition;
            float foam = (1.0 - smoothstep(0.0, 0.7, thick)) * (0.4 + 0.6 * vnoise(wp.xz * 1.7 + frameTimeCounter * 0.25))
                       * (0.6 + 0.4 * sin(frameTimeCounter * 1.3 + wp.x * 0.8 + wp.z * 0.6));
            col = mix(col, irr * 0.55, clamp(foam * 0.8, 0.0, 1.0));
        }
        vec3 dirF = normalize(dir - upN * dot(dir, upN) * 0.9);
        vec3 fogC = skyF(dirF, sunDir, upN);
        float nf = 1.0 - smoothstep(-0.2, 0.02, sunH);
        fogC += vec3(0.0035, 0.0055, 0.012) * nf;
        float fl = dot(fogC, vec3(0.333));
        fogC = mix(fogC, vec3(fl) * vec3(0.85, 0.9, 1.0) * 0.8, rainStrength * 0.8);
        fogC *= min(1.0, 2.5 / max(max(fogC.r, fogC.g), max(fogC.b, 0.001)));
        if (d < 1.0) {
            float yMid = cameraPosition.y + (mat3(gbufferModelViewInverse) * dir).y * dist * 0.5;
            float hfog = exp(-max(yMid - 64.0, 0.0) * 0.015);
            float mist = 1.0 - exp(-dist * (FOG_DENSITY * (1.0 + 2.2 * goldF(sunH)) * (0.5 + 1.0 * hfog) + 0.006 * rainStrength));
            float edge = smoothstep(far * 0.55, far * 0.98, dist);
            col = mix(col, fogC, clamp(max(mist, edge), 0.0, 1.0));
        }
#ifdef VOL_LIGHT
        {
            vec3 feetDir = mat3(gbufferModelViewInverse) * dir;
            float maxD = d < 1.0 ? min(dist, float(VOL_RANGE)) : float(VOL_RANGE);
            float ign = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
            float acc = 0.0;
            for (int i = 0; i < VOL_STEPS; i++) {
                float t = (float(i) + ign) / float(VOL_STEPS);
                vec3 pf = feetDir * (t * maxD);
                vec4 sp = shadowProjection * (shadowModelView * vec4(pf, 1.0));
                sp.xy /= length(sp.xy) * 0.9 + 0.1;
                vec3 sc = sp.xyz * 0.5 + 0.5;
                float lit = 1.0;
                if (sc.x > 0.0 && sc.x < 1.0 && sc.y > 0.0 && sc.y < 1.0 && sc.z < 1.0)
                    lit = step(sc.z - 0.0008, texture2D(shadowtex1, sc.xy).r);
                acc += lit * (0.7 + 0.6 * vnoise(pf.xz * 0.18 + pf.y * 0.07 + frameTimeCounter * 0.04));
            }
            acc /= float(VOL_STEPS);
            float lh = abs(sunH);
            vec3 sunCol = sunLight(sunH);
            vec3 moonCol = vec3(0.35, 0.5, 0.9) * 0.35 * (0.25 + 0.75 * (0.5 + 0.5 * cos(float(moonPhase) * 0.7853982)));
            vec3 lightCol = (sunH > 0.0 ? sunCol : moonCol) * smoothstep(0.0, 0.05, lh);
            float cs = dot(dir, normalize(shadowLightPosition));
            float g = 0.72;
            float ph = (1.0 - g * g) / (12.566 * pow(1.0 + g * g - 2.0 * g * cs, 1.5));
            float od = 1.0 - exp(-maxD * VOL_DENSITY);
            col += lightCol * (ph + 0.03) * od * acc * VOL_STRENGTH * (1.0 - 0.7 * rainStrength);
        }
#endif
    }
    gl_FragData[0] = vec4(col, 1.0);
}
