Solstice Potato

Built for speed: no shadows, no post-processing. Per-vertex lighting, fog, and a cheap gradient sky with sunset glow (vanilla sun, moon and stars).

Install: put the .zip (don't unzip) in .minecraft/shaderpacks, then pick it in Video Settings > Shaders. Needs Iris or OptiFine.
