#version 120
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float rainStrength;
varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 vlight;
varying float fogDist;
void main() {
    vec4 vp = gl_ModelViewMatrix * gl_Vertex;
    gl_Position = gl_ProjectionMatrix * vp;
    fogDist = length(vp.xyz);
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor = gl_Color;
    vec2 lm = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    float sky = clamp((lm.y - 0.031) / 0.9375, 0.0, 1.0);
    float blk = clamp((lm.x - 0.031) / 0.9375, 0.0, 1.0);
    vec3 n = normalize(gl_NormalMatrix * gl_Normal);
    vec3 up = normalize(upPosition);
    vec3 sun = normalize(sunPosition);
    float sunH = dot(sun, up);
    float day = smoothstep(-0.1, 0.2, sunH) * (1.0 - 0.5 * rainStrength);
    float shade = 0.8 + 0.12 * dot(n, up) + 0.12 * day * max(dot(n, sun), 0.0);
    vlight = vec3(0.9, 0.95, 1.0) * sky * mix(0.1, 1.0, day) * shade
           + vec3(1.0, 0.45, 0.14) * blk * blk * 0.95;
    vlight = max(vlight, vec3(0.04, 0.045, 0.06));
    float gold = (1.0 - smoothstep(0.15, 0.6, sunH)) * smoothstep(-0.05, 0.08, sunH);
    vlight *= mix(vec3(1.0), vec3(1.25, 0.82, 0.5), gold);
}
