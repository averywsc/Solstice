#version 120
varying vec4 starData;
uniform float viewWidth;
uniform float viewHeight;
uniform mat4 gbufferProjectionInverse;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform vec3 upPosition;
uniform vec3 sunPosition;
void main() {
    if (starData.a > 0.5) { gl_FragData[0] = vec4(starData.rgb, 1.0); return; }
    vec4 p = vec4(gl_FragCoord.xy / vec2(viewWidth, viewHeight) * 2.0 - 1.0, 1.0, 1.0);
    p = gbufferProjectionInverse * p;
    vec3 dir = normalize(p.xyz / p.w);
    vec3 upN = normalize(upPosition);
    float h = dot(dir, upN);
    vec3 col = mix(fogColor, skyColor, pow(clamp(h, 0.0, 1.0), 0.5));
    float sunH = dot(normalize(sunPosition), upN);
    float q = sunH / 0.2;
    float tw = exp(-q * q);
    float cs = max(dot(dir, normalize(sunPosition)), 0.0);
    col += vec3(1.0, 0.5, 0.25) * cs * cs * cs * tw * (1.0 - clamp(abs(h) * 2.0, 0.0, 1.0)) * 0.6;
    gl_FragData[0] = vec4(col, 1.0);
}
