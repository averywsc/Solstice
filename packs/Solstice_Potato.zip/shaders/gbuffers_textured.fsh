#version 120
uniform sampler2D texture;
varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 vlight;
varying float fogDist;
void main() {
    vec4 c = texture2D(texture, texcoord) * glcolor;
    if (c.a < 0.1) discard;
    vec3 col = c.rgb * min(vlight, vec3(1.1));
    float f = clamp((gl_Fog.end - fogDist) * gl_Fog.scale, 0.0, 1.0);
    gl_FragData[0] = vec4(mix(gl_Fog.color.rgb, col, f), c.a);
}
