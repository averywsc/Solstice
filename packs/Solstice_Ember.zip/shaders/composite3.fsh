#version 120
#define SKY_CLOUDS 1
#define CLOUD_OCT 4
#define SKY_CIRRUS 1
#define SKY_STARS 1
#define SKY_AURORA 0
#define SKY_TINT vec3(1.0, 0.604, 0.369)
#define SKY_VIVID 0
#define MOON_DETAIL 1
#define SUN_STRENGTH 0.8
#define SUN_COLOR vec3(1.0, 0.749, 0.549)
#define MOON_STRENGTH 1.0
#define AMB_STRENGTH 0.9
#define AMB_SAT 0.65
#define BOUNCE_STRENGTH 1.0
#define TORCH_STRENGTH 1.0
#define TORCH_NEAR vec3(1.0, 0.7, 0.3)
#define TORCH_FAR vec3(1.0, 0.4, 0.1)
#define EMISSIVE_STRENGTH 0.65
#define RIM_STRENGTH 1.0
#define FOLIAGE_GLOW 1.0
#define BLOCK_VARIATION 1.0
#define HELD_LIGHT 1.0
#define SHINY_STRENGTH 1.0
#define WET_STRENGTH 1.0
#define SHADOWS 2
#define SHADOW_TAPS 10
#define SHADOW_RAD 2.2
#define CLOUD_SHADOWS 1
#define FOG_DENSITY 0.0026
#define VOL_LIGHT
#define VOL_STEPS 8
#define VOL_RANGE 80
#define VOL_DENSITY 0.012
#define VOL_STRENGTH 1.0
#define WAVES_EXTRA 0
#define WATER_NORMALS 1
#define WATER_COL vec3(0.165, 0.039, 0.02)
#define WATER_SPEC 6.0
#define SSR
#define SSR_STEPS 24
#define SWAY_PLANT 0.06
#define SWAY_LEAF 0.025
#define AO_TAPS 8
#define AO_STRENGTH 0.6
#define SSL_TAPS 16
#define SSL_STRENGTH 9.0
#define SSL_RADIUS 8.0
#define GI_TAPS 16
#define GI_STRENGTH 2.0
#define GI_RADIUS 5.0
#define DOF_TAPS 2
#define DOF_STRENGTH 1.2
#define DOF_RADIUS 0.01
#define MB_STRENGTH 0.6
#define MB_MAX 0.03
#define BLOOM_TAPS 24
#define BLOOM_STRENGTH 0.4
#define BLOOM_RADIUS 0.03
#define BLOOM_THRESH 3.0
#define GODRAYS
#define GODRAY_STEPS 24
#define GODRAY_STRENGTH 0.5
#define EXPOSURE 0.36
#define AUTO_EXPOSURE
#define SAT 1.1
#define VIBRANCE 0.08
#define CONTRAST 0.15
#define VIGN 0.4
#define SHADOW_TINT vec3(1.15, 0.8, 0.7)
#define HIGH_TINT vec3(1.2, 1.0, 0.8)
#define GRADE_AMT 0.7
#define LIFT 0.0
#define LIFT_COL vec3(0.2, 0.18, 0.2)
#define SHARPEN_ON
#define SHARPEN 0.3
#define FXAA_ON
#define GBUF_ON
#ifndef GI_TAPS
#define GI_TAPS 16
#endif
#ifndef GI_STRENGTH
#define GI_STRENGTH 2.0
#endif
#ifndef GI_RADIUS
#define GI_RADIUS 5.0
#endif
varying vec2 texcoord;
uniform sampler2D colortex0;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform float viewWidth;
uniform float viewHeight;
vec3 vpAt(vec2 uv, float d) {
    vec4 p = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);
    return p.xyz / p.w;
}
void main() {
    vec3 col = texture2D(colortex0, texcoord).rgb;
    float d = texture2D(depthtex0, texcoord).r;
    vec3 albG = texture2D(colortex3, texcoord).rgb;
    vec3 nrm = texture2D(colortex4, texcoord).rgb * 2.0 - 1.0;
    if (d >= 1.0 || d < 0.56 || dot(albG, vec3(1.0)) < 0.001 || dot(nrm, nrm) < 0.1) { gl_FragData[0] = vec4(col, 1.0); return; }
    vec3 Np = normalize(nrm);
    vec3 P = vpAt(texcoord, d);
    float dist = length(P);
    float aspect = viewWidth / viewHeight;
    float r = clamp(GI_RADIUS / (dist * 1.4), 0.004, 0.15);
    float R2 = GI_RADIUS * GI_RADIUS;
    vec3 acc = vec3(0.0);
    for (int i = 0; i < GI_TAPS; i++) {
        float k = (float(i) + 0.5) / float(GI_TAPS);
        float a = float(i) * 2.39996;
        vec2 uv = clamp(texcoord + vec2(cos(a), sin(a)) * sqrt(k) * r * vec2(1.0 / aspect, 1.0), vec2(0.001), vec2(0.999));
        float ds = texture2D(depthtex0, uv).r;
        if (ds >= 1.0) continue;
        vec3 v = vpAt(uv, ds) - P;
        float d2 = dot(v, v);
        if (d2 > R2 || d2 < 0.0004) continue;
        vec3 Ns = texture2D(colortex4, uv).rgb * 2.0 - 1.0;
        if (dot(Ns, Ns) < 0.1) continue;
        Ns = normalize(Ns);
        vec3 dv = v * inversesqrt(d2);
        float g = max(dot(Np, dv), 0.0) * max(dot(Ns, -dv), 0.0);
        vec3 C = min(texture2D(colortex0, uv).rgb, vec3(3.0));
        acc += C * g / (1.0 + d2 * 0.5);
    }
    col += pow(albG, vec3(2.2)) * (acc / float(GI_TAPS)) * GI_STRENGTH;
    gl_FragData[0] = vec4(col, 1.0);
}
