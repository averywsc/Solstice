#version 120
#define SKY_CLOUDS 1
#define CLOUD_OCT 4
#define SKY_CIRRUS 1
#define SKY_STARS 1
#define SKY_AURORA 0
#define SKY_TINT vec3(1.0, 0.604, 0.369)
#define SKY_VIVID 0
#define MOON_DETAIL 1
#define SUN_STRENGTH 0.8
#define SUN_COLOR vec3(1.0, 0.749, 0.549)
#define MOON_STRENGTH 1.0
#define AMB_STRENGTH 0.9
#define AMB_SAT 0.65
#define BOUNCE_STRENGTH 1.0
#define TORCH_STRENGTH 1.0
#define TORCH_NEAR vec3(1.0, 0.7, 0.3)
#define TORCH_FAR vec3(1.0, 0.4, 0.1)
#define EMISSIVE_STRENGTH 0.65
#define RIM_STRENGTH 1.0
#define FOLIAGE_GLOW 1.0
#define BLOCK_VARIATION 1.0
#define HELD_LIGHT 1.0
#define SHINY_STRENGTH 1.0
#define WET_STRENGTH 1.0
#define SHADOWS 2
#define SHADOW_TAPS 10
#define SHADOW_RAD 2.2
#define CLOUD_SHADOWS 1
#define FOG_DENSITY 0.0026
#define VOL_LIGHT
#define VOL_STEPS 8
#define VOL_RANGE 80
#define VOL_DENSITY 0.012
#define VOL_STRENGTH 1.0
#define WAVES_EXTRA 0
#define WATER_NORMALS 1
#define WATER_COL vec3(0.165, 0.039, 0.02)
#define WATER_SPEC 6.0
#define SSR
#define SSR_STEPS 24
#define SWAY_PLANT 0.06
#define SWAY_LEAF 0.025
#define AO_TAPS 8
#define AO_STRENGTH 0.6
#define SSL_TAPS 16
#define SSL_STRENGTH 9.0
#define SSL_RADIUS 8.0
#define GI_TAPS 16
#define GI_STRENGTH 2.0
#define GI_RADIUS 5.0
#define DOF_TAPS 2
#define DOF_STRENGTH 1.2
#define DOF_RADIUS 0.01
#define MB_STRENGTH 0.6
#define MB_MAX 0.03
#define BLOOM_TAPS 24
#define BLOOM_STRENGTH 0.4
#define BLOOM_RADIUS 0.03
#define BLOOM_THRESH 3.0
#define GODRAYS
#define GODRAY_STEPS 24
#define GODRAY_STRENGTH 0.5
#define EXPOSURE 0.36
#define AUTO_EXPOSURE
#define SAT 1.1
#define VIBRANCE 0.08
#define CONTRAST 0.15
#define VIGN 0.4
#define SHADOW_TINT vec3(1.15, 0.8, 0.7)
#define HIGH_TINT vec3(1.2, 1.0, 0.8)
#define GRADE_AMT 0.7
#define LIFT 0.0
#define LIFT_COL vec3(0.2, 0.18, 0.2)
#define SHARPEN_ON
#define SHARPEN 0.3
#define FXAA_ON
#define GBUF_ON
#define TERRAIN_PROGRAM
/* DRAWBUFFERS:0234 */
#ifndef SHADOWS
#define SHADOWS 2
#endif
#ifndef SHADOW_TAPS
#define SHADOW_TAPS 10
#endif
#ifndef SHADOW_RAD
#define SHADOW_RAD 2.2
#endif
#ifndef CLOUD_SHADOWS
#define CLOUD_SHADOWS 0
#endif
#ifndef SUN_STRENGTH
#define SUN_STRENGTH 1.0
#endif
#ifndef SUN_COLOR
#define SUN_COLOR vec3(1.0)
#endif
#ifndef MOON_STRENGTH
#define MOON_STRENGTH 1.0
#endif
#ifndef AMB_STRENGTH
#define AMB_STRENGTH 1.0
#endif
#ifndef AMB_SAT
#define AMB_SAT 0.65
#endif
#ifndef BOUNCE_STRENGTH
#define BOUNCE_STRENGTH 1.0
#endif
#ifndef TORCH_STRENGTH
#define TORCH_STRENGTH 1.0
#endif
#ifndef TORCH_NEAR
#define TORCH_NEAR vec3(1.0, 0.5, 0.16)
#endif
#ifndef TORCH_FAR
#define TORCH_FAR vec3(1.0, 0.22, 0.04)
#endif
#ifndef EMISSIVE_STRENGTH
#define EMISSIVE_STRENGTH 1.0
#endif
#ifndef SHINY_STRENGTH
#define SHINY_STRENGTH 1.0
#endif
#ifndef WET_STRENGTH
#define WET_STRENGTH 1.0
#endif
#ifndef FOLIAGE_GLOW
#define FOLIAGE_GLOW 1.0
#endif
#ifndef RIM_STRENGTH
#define RIM_STRENGTH 1.0
#endif
#ifndef BLOCK_VARIATION
#define BLOCK_VARIATION 1.0
#endif
#ifndef HELD_LIGHT
#define HELD_LIGHT 1.0
#endif
#ifndef CLOUD_OCT
#define CLOUD_OCT 3
#endif
const int shadowMapResolution = 2048;
const float shadowDistance = 120.0;
const float sunPathRotation = -25.0;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPos;
vec3 gShadowTint = vec3(1.0);
varying vec3 vSunTrans;
varying vec3 vSkyAmb;
varying vec3 vAmbUp;
varying vec3 vAmbSun;
varying vec3 vAmbAway;
#ifdef TERRAIN_PROGRAM
varying float foliage;
varying float emit;
varying float shiny;
#else
const float foliage = 0.0;
const float emit = 0.0;
const float shiny = 0.0;
#endif

uniform sampler2D texture;
uniform sampler2D shadowtex0;
uniform sampler2D shadowcolor0;
uniform sampler2D shadowtex1;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 shadowLightPosition;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform vec3 skyColor;
uniform float rainStrength;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform int heldBlockLightValue;
uniform int isEyeInWater;
uniform int moonPhase;
uniform int heldItemId;

#if SHADOWS == 2
float shadowFactor(vec3 feet, vec3 wn) {
    vec3 p = feet + wn * 0.1;
    vec4 sp = shadowProjection * (shadowModelView * vec4(p, 1.0));
    sp.xy /= length(sp.xy) * 0.9 + 0.1;
    vec3 sc = sp.xyz * 0.5 + 0.5;
    if (sc.x < 0.0 || sc.x > 1.0 || sc.y < 0.0 || sc.y > 1.0 || sc.z > 1.0) return 1.0;
    sc.z -= 0.0008;
    if (texture2D(shadowtex0, sc.xy).r < sc.z && texture2D(shadowtex1, sc.xy).r >= sc.z) { vec4 c0 = texture2D(shadowcolor0, sc.xy); gShadowTint = mix(vec3(1.0), c0.rgb, c0.a); }
    float res = float(shadowMapResolution);
    float rs = res / 2048.0;
    float ign = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    float rot = ign * 6.2831853;
    float avgB = 0.0;
    float nb = 0.0;
    for (int i = 0; i < 6; i++) {
        float r = sqrt((float(i) + 0.5) / 6.0);
        float a = float(i) * 2.39996 + rot;
        vec2 o = vec2(cos(a), sin(a)) * r * (6.0 * rs / res);
        float d = texture2D(shadowtex1, sc.xy + o).r;
        if (d < sc.z) { avgB += d; nb += 1.0; }
    }
    if (nb < 0.5) return 1.0;
    avgB /= nb;
    float pen = clamp((sc.z - avgB) * 150.0 * rs, 1.2, 7.0 * rs) / res;
    float lit = 0.0;
    for (int i = 0; i < SHADOW_TAPS; i++) {
        float r = sqrt((float(i) + 0.5) / float(SHADOW_TAPS));
        float a = float(i) * 2.39996 + rot;
        vec2 o = vec2(cos(a), sin(a)) * r * pen;
        lit += step(sc.z, texture2D(shadowtex1, sc.xy + o).r);
    }
    lit /= 20.0;
    float fade = smoothstep(0.8, 1.0, length(feet) / shadowDistance);
    return mix(lit, 1.0, fade);
}
#elif SHADOWS == 1
float shadowFactor(vec3 feet, vec3 wn) {
    vec3 p = feet + wn * 0.1;
    vec4 sp = shadowProjection * (shadowModelView * vec4(p, 1.0));
    sp.xy /= length(sp.xy) * 0.9 + 0.1;
    vec3 sc = sp.xyz * 0.5 + 0.5;
    if (sc.x < 0.0 || sc.x > 1.0 || sc.y < 0.0 || sc.y > 1.0 || sc.z > 1.0) return 1.0;
    sc.z -= 0.0008;
    if (texture2D(shadowtex0, sc.xy).r < sc.z && texture2D(shadowtex1, sc.xy).r >= sc.z) { vec4 c0 = texture2D(shadowcolor0, sc.xy); gShadowTint = mix(vec3(1.0), c0.rgb, c0.a); }
    float res = float(shadowMapResolution);
    float ign = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    float rot = ign * 6.2831853;
    float lit = 0.0;
    for (int i = 0; i < SHADOW_TAPS; i++) {
        float r = sqrt((float(i) + 0.5) / float(SHADOW_TAPS));
        float a = float(i) * 2.39996 + rot;
        vec2 o = vec2(cos(a), sin(a)) * r * (SHADOW_RAD / res);
        lit += step(sc.z, texture2D(shadowtex1, sc.xy + o).r);
    }
    lit /= float(SHADOW_TAPS);
    float fade = smoothstep(0.8, 1.0, length(feet) / shadowDistance);
    return mix(lit, 1.0, fade);
}
#endif


float hash21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vnoise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash21(i), hash21(i + vec2(1.0, 0.0)), f.x),
               mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), f.x), f.y);
}
float fbm4(vec2 p) {
    float a = 0.5; float s = 0.0;
    for (int i = 0; i < 4; i++) { s += a * vnoise(p); p = p * 2.02 + 3.7; a *= 0.5; }
    return s;
}
float fbmC(vec2 p) {
    float a = 0.5; float s = 0.0;
    for (int i = 0; i < CLOUD_OCT; i++) { s += a * vnoise(p); p = p * 2.03 + 1.9; a *= 0.5; }
    return s;
}
float h31(vec3 p) { p = fract(p * 0.1031); p += dot(p, p.yzx + 33.33); return fract((p.x + p.y) * p.z); }
vec3 starField(vec3 d) {
    vec3 q = d * 80.0;
    vec3 id = floor(q);
    vec3 f = fract(q) - 0.5;
    float r = h31(id);
    vec3 off = vec3(h31(id + 11.1), h31(id + 23.7), h31(id + 37.3)) - 0.5;
    float s = smoothstep(0.14, 0.0, length(f - off * 0.7)) * step(0.93, r);
    vec3 tint = mix(vec3(0.7, 0.8, 1.0), vec3(1.0, 0.85, 0.7), h31(id + 5.5));
    return tint * s * (1.5 + 3.0 * fract(r * 13.7));
}
vec3 rotAxis(vec3 v, vec3 k, float a) {
    return v * cos(a) + cross(k, v) * sin(a) + k * dot(k, v) * (1.0 - cos(a));
}
vec3 aurora(vec3 d, float t) {
    if (d.y < 0.02) return vec3(0.0);
    vec3 acc = vec3(0.0);
    for (int i = 0; i < 6; i++) {
        float fi = float(i);
        vec2 p = d.xz / (d.y + 0.25) * (0.8 + fi * 0.18);
        float wob = vnoise(vec2(p.x * 0.5 + t * 0.03, fi * 3.1)) * 3.0;
        float v = p.y * 0.9 + wob;
        float qq = fract(v) - 0.5;
        float rib = exp(-qq * qq * 60.0);
        float flick = 0.6 + 0.4 * vnoise(vec2(p.x * 1.3 - t * 0.15, fi));
        vec3 c = mix(vec3(0.15, 1.0, 0.45), vec3(0.45, 0.3, 1.0), clamp(fi / 5.0 * 0.9 + wob * 0.03, 0.0, 1.0));
        acc += c * rib * flick * (1.0 - fi * 0.1);
    }
    float fade = smoothstep(0.02, 0.3, d.y) * (1.0 - smoothstep(0.55, 0.95, d.y) * 0.6);
    return acc * 0.35 * fade;
}


vec3 heldColor(int id) {
    if (id == 10012) return vec3(0.3, 0.65, 1.0);
    if (id == 10011) return vec3(1.0, 0.35, 0.08);
    if (id == 10013) return vec3(0.85, 1.0, 1.0);
    if (id == 10014) return vec3(0.5, 1.0, 0.45);
    if (id == 10015) return vec3(1.0, 0.4, 0.8);
    if (id == 10016) return vec3(1.0, 0.15, 0.1);
    return vec3(1.0, 0.62, 0.3);
}
float hashf(float n) { return fract(sin(n * 12.9898) * 43758.5453); }
float torchFlicker(vec3 wp, float t) {
    float cell = floor(wp.x / 5.0) * 7.13 + floor(wp.z / 5.0) * 3.77 + floor(wp.y / 5.0) * 1.31;
    float a = t * 8.0 + hashf(cell) * 50.0;
    return 0.9 + 0.07 * sin(a) + 0.05 * sin(a * 2.3 + 1.7) + 0.04 * hashf(floor(a * 3.0) + cell);
}
float causticPat(vec2 p, float t) {
    float a = sin(p.x * 2.0 + sin(p.y * 1.5 + t * 1.2) * 1.5 + t);
    float b = sin(p.y * 2.3 + sin(p.x * 1.7 - t) * 1.5 - t * 0.8);
    float v = abs(a + b) * 0.5;
    return pow(1.0 - v, 6.0);
}

void main() {
    vec4 tex = texture2D(texture, texcoord);
    if (tex.a < 0.1) discard;
    vec3 albedo = pow(tex.rgb * glcolor.rgb, vec3(2.2));

    vec3 n = normalize(normal);
    vec3 wn = mat3(gbufferModelViewInverse) * n;
    vec3 feet = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
#ifdef TERRAIN_PROGRAM
    albedo *= 1.0 - 0.07 * BLOCK_VARIATION + 0.14 * BLOCK_VARIATION * hashf(dot(floor(feet + cameraPosition - wn * 0.01), vec3(7.13, 3.77, 1.31)));
#endif

    float skyL = clamp((lmcoord.y - 0.031) / 0.9375, 0.0, 1.0);
    float blkL = clamp((lmcoord.x - 0.031) / 0.9375, 0.0, 1.0);
    skyL = skyL * skyL;
    blkL = pow(blkL, 2.5);

    // sun / moon
    float sunH = dot(normalize(sunPosition), normalize(upPosition));
    float lh = abs(sunH);
    vec3 sunCol = vSunTrans * 3.4 * SUN_STRENGTH * SUN_COLOR;
    float moonI = 0.25 + 0.75 * (0.5 + 0.5 * cos(float(moonPhase) * 0.7853982));
    vec3 moonCol = vec3(0.48, 0.58, 0.85) * 0.35 * moonI * MOON_STRENGTH;
    vec3 lightCol = (sunH > 0.0 ? sunCol : moonCol) * smoothstep(0.0, 0.1, lh);
    lightCol *= 1.0 - 0.85 * rainStrength;

    vec3 L = normalize(shadowLightPosition);
    float ndl = max(dot(n, L), 0.0);
    ndl = mix(ndl, max(dot(n, L) * 0.5 + 0.5, 0.0), foliage);
#if SHADOWS > 0
    float sh = ndl > 0.0 ? shadowFactor(feet, wn) : 0.0;
    sh *= smoothstep(0.15, 0.6, skyL);
#else
    float sh = smoothstep(0.35, 0.8, skyL);
#endif
#if CLOUD_SHADOWS
    vec3 sunW = mat3(gbufferModelViewInverse) * L;
    if (sunH > 0.0 && sunW.y > 0.05) {
        vec2 cp = (feet.xz + cameraPosition.xz + sunW.xz / sunW.y * 100.0) * 0.004 + vec2(frameTimeCounter * 0.012, frameTimeCounter * 0.004);
        float cov = mix(0.5, 0.3, rainStrength);
        sh *= 1.0 - smoothstep(cov, cov + 0.25, fbmC(cp)) * 0.65;
    }
#endif
    vec3 direct = lightCol * ndl * sh * gShadowTint;
    direct += lightCol * vec3(1.1, 1.1, 0.6) * foliage * pow(max(dot(normalize(viewPos), L), 0.0), 4.0) * 0.5 * FOLIAGE_GLOW * sh;
    if (isEyeInWater == 1) {
        direct *= 1.0 + 3.0 * causticPat((feet.xz + cameraPosition.xz) * 0.8, frameTimeCounter) * smoothstep(0.3, 0.8, skyL);
    }

    // directional sky ambient: sun side, away side, zenith, ground bounce
    vec3 upV = normalize(upPosition);
    vec3 sunV = normalize(sunPosition);
    vec3 hsV = sunV - upV * dot(sunV, upV);
    hsV = length(hsV) > 0.001 ? normalize(hsV) : vec3(0.0);
    float hsn = dot(n, hsV);
    float upn = dot(n, upV);
    vec3 skyHem = mix(vAmbAway, vAmbSun, hsn * 0.5 + 0.5);
    vec3 skyPart = mix(skyHem, vAmbUp, clamp(upn, 0.0, 1.0) * 0.7);
    vec3 gnd = skyHem * 0.35 + lightCol * 0.14 * vec3(1.0, 0.85, 0.65) + vec3(0.02, 0.018, 0.012);
    float skyW = clamp(upn * 0.5 + 0.5, 0.0, 1.0);
    vec3 amb = skyPart * skyW + gnd * (1.0 - skyW);
    amb = mix(vec3(dot(amb, vec3(0.333))), amb, AMB_SAT) * AMB_STRENGTH;
    amb += vec3(0.018, 0.02, 0.03);
    float nightF2 = 1.0 - smoothstep(-0.2, 0.02, sunH);
    amb += vec3(0.30, 0.36, 0.52) * 0.05 * moonI * nightF2 * (0.6 + 0.4 * dot(n, -sunV));
    amb += lightCol * skyL * 0.05 * BOUNCE_STRENGTH * vec3(1.0, 0.85, 0.65);
    float ndvR = max(dot(n, -normalize(viewPos)), 0.0);
    vec3 rimC = vAmbSun * pow(1.0 - ndvR, 3.0) * (0.5 + 0.5 * hsn) * 0.5 * RIM_STRENGTH;
    float flick = torchFlicker(feet + cameraPosition, frameTimeCounter);
    vec3 torchCol = mix(TORCH_FAR, TORCH_NEAR, clamp(blkL * 1.6, 0.0, 1.0));
    vec3 torch = torchCol * blkL * 1.5 * TORCH_STRENGTH * flick;

    vec3 col = albedo * (amb * skyL + direct + torch + rimC * skyL + lightCol * sh * gShadowTint * max(ndl, 0.0) * pow(1.0 - ndvR, 4.0) * 0.5 * RIM_STRENGTH);
    vec3 emOut = vec3(0.0);
    float lumT = dot(tex.rgb, vec3(0.3, 0.6, 0.1));
    float em = smoothstep(0.55, 0.9, lumT);
    if (emit > 10009.5 && emit < 10016.5) {
        vec3 emC = emit < 10010.5 ? vec3(1.0, 0.62, 0.28) : (emit < 10011.5 ? vec3(1.0, 0.35, 0.08) : (emit < 10012.5 ? vec3(0.25, 0.65, 1.0) : (emit < 10013.5 ? vec3(0.85, 1.0, 1.0) : (emit < 10014.5 ? vec3(0.5, 1.0, 0.45) : (emit < 10015.5 ? vec3(1.0, 0.4, 0.8) : vec3(1.0, 0.15, 0.1))))));
        col += (albedo * 0.6 + emC * 0.4 * lumT) * em * 6.0 * EMISSIVE_STRENGTH * flick;
        emOut = emC * em;
    }
    col += albedo * smoothstep(0.93, 0.96, lmcoord.x) * 0.6;
    emOut = max(emOut, vec3(1.0, 0.62, 0.28) * smoothstep(0.93, 0.96, lmcoord.x) * 0.6);
    float hl = float(heldBlockLightValue) / 15.0;
    if (hl > 0.0) {
        float hd = length(viewPos);
        float hatt = pow(clamp(1.0 - hd / (3.0 + hl * 11.0), 0.0, 1.0), 2.0);
        float face = 0.5 + 0.5 * max(dot(n, -normalize(viewPos)), 0.0);
        col += albedo * heldColor(heldItemId) * hatt * hl * 2.4 * HELD_LIGHT * face * flick;
    }

    {
        float wetM = rainStrength * WET_STRENGTH * smoothstep(0.55, 0.9, wn.y) * smoothstep(0.3, 0.7, skyL) * (1.0 - foliage);
        vec3 Vw = -normalize(viewPos);
        float fw = 0.04 + 0.96 * pow(1.0 - max(dot(n, Vw), 0.0), 5.0);
        col *= 1.0 - 0.35 * wetM;
        col += vSkyAmb * 1.5 * fw * wetM + lightCol * pow(max(dot(reflect(-L, n), Vw), 0.0), 60.0) * wetM * 0.6 * sh;
    }
    if (shiny > 0.1 && SHINY_STRENGTH > 0.0) {
        vec3 Vs = -normalize(viewPos);
        if (shiny < 0.4) {
            float spk = step(0.985, hashf(dot(floor((feet + cameraPosition) * 8.0), vec3(12.9898, 78.233, 37.719)) + floor(frameTimeCounter * 0.7)));
            col += lightCol * spk * sh * 2.0 * SHINY_STRENGTH;
        } else {
            float metal = shiny > 0.75 ? 1.0 : 0.0;
            float nv = max(dot(n, Vs), 0.0);
            float f0 = mix(0.04, 0.6, metal);
            float fr = f0 + (1.0 - f0) * pow(1.0 - nv, 5.0);
            vec3 Rv = reflect(-Vs, n);
            vec3 env = (mix(vAmbAway * 0.4 + lightCol * 0.05, vAmbUp, smoothstep(-0.2, 0.5, dot(Rv, upV))) + vAmbSun * pow(max(dot(Rv, sunV), 0.0), 6.0) * 0.8) * 0.6;
            vec3 specTint = mix(vec3(1.0), albedo * 2.2, metal);
            float expn = mix(40.0, 90.0, metal);
            float nh = max(dot(n, normalize(L + Vs)), 0.0);
            col = col * (1.0 - fr * 0.5 * metal);
            col += specTint * (env * fr * skyL + lightCol * sh * pow(nh, expn) * (0.4 + 2.0 * metal)) * SHINY_STRENGTH;
        }
    }
    gl_FragData[0] = vec4(col, tex.a * glcolor.a);
#ifdef GBUF_ON
    gl_FragData[1] = vec4(emOut, 1.0);
    gl_FragData[2] = vec4(tex.rgb * glcolor.rgb, 1.0);
    gl_FragData[3] = vec4(n * 0.5 + 0.5, 1.0);
#endif
}
