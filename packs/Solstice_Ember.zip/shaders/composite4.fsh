#version 120
#define SKY_CLOUDS 1
#define CLOUD_OCT 4
#define SKY_CIRRUS 1
#define SKY_STARS 1
#define SKY_AURORA 0
#define SKY_TINT vec3(1.0, 0.604, 0.369)
#define SKY_VIVID 0
#define MOON_DETAIL 1
#define SUN_STRENGTH 0.8
#define SUN_COLOR vec3(1.0, 0.749, 0.549)
#define MOON_STRENGTH 1.0
#define AMB_STRENGTH 0.9
#define AMB_SAT 0.65
#define BOUNCE_STRENGTH 1.0
#define TORCH_STRENGTH 1.0
#define TORCH_NEAR vec3(1.0, 0.7, 0.3)
#define TORCH_FAR vec3(1.0, 0.4, 0.1)
#define EMISSIVE_STRENGTH 0.65
#define RIM_STRENGTH 1.0
#define FOLIAGE_GLOW 1.0
#define BLOCK_VARIATION 1.0
#define HELD_LIGHT 1.0
#define SHINY_STRENGTH 1.0
#define WET_STRENGTH 1.0
#define SHADOWS 2
#define SHADOW_TAPS 10
#define SHADOW_RAD 2.2
#define CLOUD_SHADOWS 1
#define FOG_DENSITY 0.0026
#define VOL_LIGHT
#define VOL_STEPS 8
#define VOL_RANGE 80
#define VOL_DENSITY 0.012
#define VOL_STRENGTH 1.0
#define WAVES_EXTRA 0
#define WATER_NORMALS 1
#define WATER_COL vec3(0.165, 0.039, 0.02)
#define WATER_SPEC 6.0
#define SSR
#define SSR_STEPS 24
#define SWAY_PLANT 0.06
#define SWAY_LEAF 0.025
#define AO_TAPS 8
#define AO_STRENGTH 0.6
#define SSL_TAPS 16
#define SSL_STRENGTH 9.0
#define SSL_RADIUS 8.0
#define GI_TAPS 16
#define GI_STRENGTH 2.0
#define GI_RADIUS 5.0
#define DOF_TAPS 2
#define DOF_STRENGTH 1.2
#define DOF_RADIUS 0.01
#define MB_STRENGTH 0.6
#define MB_MAX 0.03
#define BLOOM_TAPS 24
#define BLOOM_STRENGTH 0.4
#define BLOOM_RADIUS 0.03
#define BLOOM_THRESH 3.0
#define GODRAYS
#define GODRAY_STEPS 24
#define GODRAY_STRENGTH 0.5
#define EXPOSURE 0.36
#define AUTO_EXPOSURE
#define SAT 1.1
#define VIBRANCE 0.08
#define CONTRAST 0.15
#define VIGN 0.4
#define SHADOW_TINT vec3(1.15, 0.8, 0.7)
#define HIGH_TINT vec3(1.2, 1.0, 0.8)
#define GRADE_AMT 0.7
#define LIFT 0.0
#define LIFT_COL vec3(0.2, 0.18, 0.2)
#define SHARPEN_ON
#define SHARPEN 0.3
#define FXAA_ON
#define GBUF_ON
#ifndef BLOOM_TAPS
#define BLOOM_TAPS 16
#endif
#ifndef BLOOM_RADIUS
#define BLOOM_RADIUS 0.03
#endif
#ifndef BLOOM_THRESH
#define BLOOM_THRESH 2.5
#endif
#ifndef BLOOM_STRENGTH
#define BLOOM_STRENGTH 0.4
#endif
#ifndef BLOOM_WIDE_STRENGTH
#define BLOOM_WIDE_STRENGTH 0.4
#endif
#ifndef GODRAY_STEPS
#define GODRAY_STEPS 20
#endif
#ifndef GODRAY_STRENGTH
#define GODRAY_STRENGTH 0.4
#endif
#ifndef GODRAY_DENSITY
#define GODRAY_DENSITY 0.9
#endif
#ifndef GODRAY_DECAY
#define GODRAY_DECAY 0.95
#endif
#ifndef FLARE_STRENGTH
#define FLARE_STRENGTH 0.3
#endif
#ifndef ANAMORPHIC_LEN
#define ANAMORPHIC_LEN 0.12
#endif
#ifndef ANAMORPHIC_THRESH
#define ANAMORPHIC_THRESH 2.4
#endif
#ifndef ANAMORPHIC_STRENGTH
#define ANAMORPHIC_STRENGTH 0.5
#endif
#ifndef DIRT_AMT
#define DIRT_AMT 0.6
#endif
#ifndef HALATION_AMT
#define HALATION_AMT 0.5
#endif
varying vec2 texcoord;
uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform float viewWidth;
uniform float viewHeight;
uniform float rainStrength;
uniform mat4 gbufferProjection;
uniform vec3 sunPosition;
uniform vec3 upPosition;
#ifdef LENSDIRT
float hash21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vnoise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash21(i), hash21(i + vec2(1.0, 0.0)), f.x), mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), f.x), f.y);
}
#endif
float lum(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
float ghost(vec2 p, vec2 c, float r) { float d = length(p - c); float ring = smoothstep(r * 0.55, r * 0.95, d) * (1.0 - smoothstep(r * 0.95, r, d)); return ring * 0.9 + (1.0 - smoothstep(0.0, r, d)) * 0.12; }
void main() {
    vec2 uv = texcoord;
    float aspect = viewWidth / viewHeight;
    vec3 col = texture2D(colortex0, uv).rgb;
    float ign = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    float dirtMul = 1.0;
#ifdef LENSDIRT
    dirtMul = 1.0 + DIRT_AMT * 4.0 * pow(vnoise(uv * vec2(aspect, 1.0) * 5.0 + 3.1) * 0.6 + vnoise(uv * vec2(aspect, 1.0) * 17.0) * 0.4, 3.0);
#endif

#if BLOOM_TAPS > 0
    vec3 bl = vec3(0.0);
    for (int i = 0; i < BLOOM_TAPS; i++) {
        float r = sqrt((float(i) + 0.5) / float(BLOOM_TAPS));
        float a = float(i) * 2.39996 + ign * 6.2831853;
        vec2 o = vec2(cos(a), sin(a)) * r * BLOOM_RADIUS * vec2(1.0 / aspect, 1.0);
        bl += max(texture2D(colortex0, uv + o).rgb - vec3(BLOOM_THRESH), vec3(0.0));
    }
    col += bl / float(BLOOM_TAPS) * BLOOM_STRENGTH * dirtMul;
#ifdef HALATION
    col += bl / float(BLOOM_TAPS) * BLOOM_STRENGTH * vec3(0.7, 0.12, 0.03) * HALATION_AMT * dirtMul;
#endif
#endif
#ifdef BLOOM_WIDE
    vec3 bw = vec3(0.0);
    for (int i = 0; i < BLOOM_TAPS; i++) {
        float r = sqrt((float(i) + 0.5) / float(BLOOM_TAPS));
        float a = float(i) * 2.39996 + ign * 6.2831853;
        vec2 o = vec2(cos(a), sin(a)) * r * BLOOM_RADIUS * 3.5 * vec2(1.0 / aspect, 1.0);
        bw += max(texture2D(colortex0, uv + o).rgb - vec3(BLOOM_THRESH * 0.6), vec3(0.0));
    }
    col += bw / float(BLOOM_TAPS) * BLOOM_WIDE_STRENGTH * dirtMul;
#endif
#ifdef ANAMORPHIC
    vec3 st = vec3(0.0);
    float ws = 0.0;
    for (int i = 0; i < 16; i++) {
        float x = (float(i) - 7.5) / 7.5;
        float w = exp(-x * x * 2.0);
        st += max(texture2D(colortex0, clamp(uv + vec2(x * ANAMORPHIC_LEN, 0.0), vec2(0.001), vec2(0.999))).rgb - vec3(ANAMORPHIC_THRESH), vec3(0.0)) * w;
        ws += w;
    }
    col += st / ws * vec3(0.35, 0.6, 1.2) * ANAMORPHIC_STRENGTH;
#endif

    vec3 sp3 = normalize(sunPosition);
    vec4 spc = gbufferProjection * vec4(sunPosition, 1.0);
    vec2 suv = spc.xy / spc.w * 0.5 + 0.5;
    float facing = -sp3.z;
    float sunH = dot(sp3, normalize(upPosition));
    float dayv = smoothstep(0.0, 0.15, sunH) * (1.0 - rainStrength * 0.8);
    vec3 sunTint = mix(vec3(1.0, 0.5, 0.22), vec3(1.0, 0.92, 0.78), smoothstep(0.0, 0.35, sunH));

#ifdef GODRAYS
    if (facing > 0.0 && dayv > 0.0) {
        vec2 delta = (suv - uv) * (GODRAY_DENSITY / float(GODRAY_STEPS));
        vec2 pp = uv + delta * ign;
        float illum = 1.0;
        float acc = 0.0;
        for (int i = 0; i < GODRAY_STEPS; i++) {
            pp += delta;
            vec2 pc = clamp(pp, vec2(0.001), vec2(0.999));
            float sk = step(0.9999, texture2D(depthtex0, pc).r);
            acc += clamp(lum(texture2D(colortex0, pc).rgb) - 0.9, 0.0, 4.0) * sk * illum;
            illum *= GODRAY_DECAY;
        }
        col += vec3(acc / float(GODRAY_STEPS)) * sunTint * GODRAY_STRENGTH * smoothstep(0.0, 0.35, facing) * dayv;
    }
#endif

#ifdef FLARE
    if (facing > 0.05 && dayv > 0.0) {
        float onscreen = smoothstep(-0.2, 0.1, min(min(suv.x, 1.0 - suv.x), min(suv.y, 1.0 - suv.y)));
        vec2 cs = clamp(suv, vec2(0.02), vec2(0.98));
        float vis = 0.0;
        vis += step(0.9999, texture2D(depthtex0, cs + vec2(0.01, 0.0)).r);
        vis += step(0.9999, texture2D(depthtex0, cs - vec2(0.01, 0.0)).r);
        vis += step(0.9999, texture2D(depthtex0, cs + vec2(0.0, 0.01)).r);
        vis += step(0.9999, texture2D(depthtex0, cs - vec2(0.0, 0.01)).r);
        vis = vis * 0.25 * onscreen;
        vec2 sc = (suv - 0.5) * vec2(aspect, 1.0);
        vec2 pc = (uv - 0.5) * vec2(aspect, 1.0);
        vec3 fl = vec3(0.0);
        fl += vec3(1.0, 0.7, 0.4) * ghost(pc, -sc * 0.55, 0.03) * 0.3;
        fl += vec3(0.55, 0.6, 1.0) * ghost(pc, -sc * 1.0, 0.05) * 0.18;
        fl += vec3(0.8, 0.5, 1.0) * ghost(pc, -sc * 1.5, 0.02) * 0.25;
        fl += vec3(1.0, 0.9, 0.6) * ghost(pc, -sc * 0.25, 0.06) * 0.1;
        fl += vec3(0.35, 0.55, 1.0) * exp(-abs(pc.y - sc.y) * 60.0) * exp(-abs(pc.x - sc.x) * 2.5) * 0.8;
        fl += vec3(1.0, 0.85, 0.6) * exp(-length(pc - sc) * 14.0) * 0.25;
        col += fl * 3.0 * vis * FLARE_STRENGTH * smoothstep(0.05, 0.3, facing) * dayv;
    }
#endif
    gl_FragData[0] = vec4(col, 1.0);
}
