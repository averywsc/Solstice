Solstice Ember

An apocalyptic sunset that never leaves: red-orange skies, thick haze and glowing amber light.

Install: put the .zip (do not unzip) in .minecraft/shaderpacks, then pick it in Video Settings > Shaders. Needs Iris or OptiFine.
Most options can also be changed in-game under Shader Options.
