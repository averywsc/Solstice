#version 120
#define SKY_CLOUDS 1
#define CLOUD_OCT 4
#define SKY_CIRRUS 1
#define SKY_STARS 2
#define SKY_AURORA 1
#define SKY_TINT vec3(0.851, 0.949, 1.0)
#define SKY_VIVID 0
#define MOON_DETAIL 1
#define SUN_STRENGTH 0.8
#define SUN_COLOR vec3(0.902, 0.957, 1.0)
#define MOON_STRENGTH 1.0
#define AMB_STRENGTH 1.15
#define AMB_SAT 0.65
#define BOUNCE_STRENGTH 1.0
#define TORCH_STRENGTH 1.0
#define TORCH_NEAR vec3(1.0, 0.85, 0.65)
#define TORCH_FAR vec3(1.0, 0.55, 0.3)
#define EMISSIVE_STRENGTH 0.65
#define RIM_STRENGTH 1.0
#define FOLIAGE_GLOW 1.0
#define BLOCK_VARIATION 1.0
#define HELD_LIGHT 1.0
#define SHINY_STRENGTH 1.0
#define WET_STRENGTH 1.0
#define SHADOWS 2
#define SHADOW_TAPS 10
#define SHADOW_RAD 2.2
#define CLOUD_SHADOWS 1
#define FOG_DENSITY 0.0018
#define VOL_LIGHT
#define VOL_STEPS 8
#define VOL_RANGE 80
#define VOL_DENSITY 0.012
#define VOL_STRENGTH 1.0
#define WAVES_EXTRA 0
#define WATER_NORMALS 1
#define WATER_COL vec3(0.039, 0.165, 0.184)
#define WATER_SPEC 6.0
#define SSR
#define SSR_STEPS 24
#define SWAY_PLANT 0.06
#define SWAY_LEAF 0.025
#define AO_TAPS 8
#define AO_STRENGTH 0.6
#define SSL_TAPS 16
#define SSL_STRENGTH 9.0
#define SSL_RADIUS 8.0
#define GI_TAPS 16
#define GI_STRENGTH 2.0
#define GI_RADIUS 5.0
#define DOF_TAPS 2
#define DOF_STRENGTH 1.2
#define DOF_RADIUS 0.01
#define MB_STRENGTH 0.6
#define MB_MAX 0.03
#define BLOOM_TAPS 20
#define BLOOM_STRENGTH 0.3
#define BLOOM_RADIUS 0.03
#define BLOOM_THRESH 3.0
#define GODRAYS
#define GODRAY_STEPS 20
#define GODRAY_STRENGTH 0.3
#define EXPOSURE 0.36
#define AUTO_EXPOSURE
#define SAT 0.85
#define VIBRANCE 0.2
#define CONTRAST 0.15
#define VIGN 0.4
#define SHADOW_TINT vec3(0.9, 0.97, 1.1)
#define HIGH_TINT vec3(0.96, 1.0, 1.08)
#define GRADE_AMT 0.5
#define LIFT 0.0
#define LIFT_COL vec3(0.2, 0.18, 0.2)
#define SHARPEN_ON
#define SHARPEN 0.3
#define FXAA_ON
#define GBUF_ON
varying vec2 texcoord;
varying vec4 glcolor;
void main() {
    gl_Position = ftransform();
    gl_Position.xy /= length(gl_Position.xy) * 0.9 + 0.1;
    texcoord = gl_MultiTexCoord0.xy;
    glcolor = gl_Color;
}
