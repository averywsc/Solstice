Solstice Epic

The heaviest pack: volumetric light shafts, autofocus depth of field, motion blur and a heavy film grade. It fills the whole screen. Optional cinema bars (Shader Options) crop to 2.39:1, which is not a normal 16:9 ratio. Very demanding.

Install: put the .zip (do not unzip) in .minecraft/shaderpacks, then pick it in Video Settings > Shaders. Needs Iris or OptiFine.
Most options can also be changed in-game under Shader Options.
