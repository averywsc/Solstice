#version 120
#define SKY_CLOUDS 1
#define CLOUD_OCT 3
#define SKY_CIRRUS 0
#define SKY_STARS 1
#define SKY_AURORA 0
#define SKY_TINT vec3(1.0, 1.0, 1.0)
#define SKY_VIVID 1
#define MOON_DETAIL 1
#define SUN_STRENGTH 0.8
#define SUN_COLOR vec3(1.0, 1.0, 1.0)
#define MOON_STRENGTH 1.0
#define AMB_STRENGTH 1.0
#define AMB_SAT 0.9
#define BOUNCE_STRENGTH 1.0
#define TORCH_STRENGTH 1.0
#define TORCH_NEAR vec3(1.0, 0.5, 0.16)
#define TORCH_FAR vec3(1.0, 0.22, 0.04)
#define EMISSIVE_STRENGTH 0.65
#define RIM_STRENGTH 1.0
#define FOLIAGE_GLOW 1.0
#define BLOCK_VARIATION 1.0
#define HELD_LIGHT 1.0
#define SHINY_STRENGTH 1.0
#define WET_STRENGTH 1.0
#define SHADOWS 1
#define SHADOW_TAPS 4
#define SHADOW_RAD 2.2
#define CLOUD_SHADOWS 0
#define FOG_DENSITY 0.0009
#define VOL_LIGHT
#define VOL_STEPS 6
#define VOL_RANGE 80
#define VOL_DENSITY 0.012
#define VOL_STRENGTH 1.0
#define WAVES_EXTRA 0
#define WATER_NORMALS 1
#define WATER_COL vec3(0.0, 0.2, 0.251)
#define WATER_SPEC 6.0
#define SWAY_PLANT 0.1
#define SWAY_LEAF 0.04
#define AO_TAPS 6
#define AO_STRENGTH 0.6
#define SSL_TAPS 10
#define SSL_STRENGTH 9.0
#define SSL_RADIUS 8.0
#define GI_TAPS 2
#define GI_STRENGTH 2.0
#define GI_RADIUS 5.0
#define DOF_TAPS 2
#define DOF_STRENGTH 1.2
#define DOF_RADIUS 0.01
#define MB_STRENGTH 0.6
#define MB_MAX 0.03
#define BLOOM_TAPS 12
#define BLOOM_STRENGTH 0.3
#define BLOOM_RADIUS 0.03
#define BLOOM_THRESH 3.0
#define GODRAYS
#define GODRAY_STEPS 12
#define GODRAY_STRENGTH 0.3
#define EXPOSURE 0.36
#define AUTO_EXPOSURE
#define SAT 1.2
#define VIBRANCE 0.45
#define CONTRAST 0.3
#define VIGN 0.4
#define SHADOW_TINT vec3(1.0)
#define HIGH_TINT vec3(1.0)
#define GRADE_AMT 0.0
#define LIFT 0.0
#define LIFT_COL vec3(0.2, 0.18, 0.2)
#define SHARPEN_ON
#define SHARPEN 0.3
#define FXAA_ON
#define GBUF_ON
#ifndef AO_TAPS
#define AO_TAPS 8
#endif
#ifndef AO_STRENGTH
#define AO_STRENGTH 0.6
#endif
varying vec2 texcoord;
uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform float near;
uniform float far;
uniform float viewWidth;
uniform float viewHeight;
float linD(float d) { return 2.0 * near * far / (far + near - (d * 2.0 - 1.0) * (far - near)); }
void main() {
    vec3 col = texture2D(colortex0, texcoord).rgb;
    float d = texture2D(depthtex0, texcoord).r;
    if (d >= 1.0 || d < 0.56) { gl_FragData[0] = vec4(col, 1.0); return; }
    float z = linD(d);
    float aspect = viewWidth / viewHeight;
    float ign = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    float r = clamp(0.9 / z, 0.003, 0.035);
    float occ = 0.0;
    for (int i = 0; i < AO_TAPS; i++) {
        float k = (float(i) + 0.5) / float(AO_TAPS);
        float a = float(i) * 2.39996 + ign * 6.2831853;
        vec2 o = vec2(cos(a), sin(a)) * sqrt(k) * r * vec2(1.0 / aspect, 1.0);
        float z2 = linD(texture2D(depthtex0, clamp(texcoord + o, vec2(0.001), vec2(0.999))).r);
        float diff = z - z2;
        occ += smoothstep(0.05, 0.5, diff) * (1.0 - smoothstep(1.0, 3.0, diff));
    }
    float ao = 1.0 - occ / float(AO_TAPS) * AO_STRENGTH * (1.0 - smoothstep(40.0, 90.0, z));
    gl_FragData[0] = vec4(col * ao, 1.0);
}
