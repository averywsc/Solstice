#version 120
#define SKY_CLOUDS 1
#define CLOUD_OCT 3
#define SKY_CIRRUS 0
#define SKY_STARS 1
#define SKY_AURORA 0
#define SKY_TINT vec3(1.0, 1.0, 1.0)
#define SKY_VIVID 1
#define MOON_DETAIL 1
#define SUN_STRENGTH 0.8
#define SUN_COLOR vec3(1.0, 1.0, 1.0)
#define MOON_STRENGTH 1.0
#define AMB_STRENGTH 1.0
#define AMB_SAT 0.9
#define BOUNCE_STRENGTH 1.0
#define TORCH_STRENGTH 1.0
#define TORCH_NEAR vec3(1.0, 0.5, 0.16)
#define TORCH_FAR vec3(1.0, 0.22, 0.04)
#define EMISSIVE_STRENGTH 0.65
#define RIM_STRENGTH 1.0
#define FOLIAGE_GLOW 1.0
#define BLOCK_VARIATION 1.0
#define HELD_LIGHT 1.0
#define SHINY_STRENGTH 1.0
#define WET_STRENGTH 1.0
#define SHADOWS 1
#define SHADOW_TAPS 4
#define SHADOW_RAD 2.2
#define CLOUD_SHADOWS 0
#define FOG_DENSITY 0.0009
#define VOL_LIGHT
#define VOL_STEPS 6
#define VOL_RANGE 80
#define VOL_DENSITY 0.012
#define VOL_STRENGTH 1.0
#define WAVES_EXTRA 0
#define WATER_NORMALS 1
#define WATER_COL vec3(0.0, 0.2, 0.251)
#define WATER_SPEC 6.0
#define SWAY_PLANT 0.1
#define SWAY_LEAF 0.04
#define AO_TAPS 6
#define AO_STRENGTH 0.6
#define SSL_TAPS 10
#define SSL_STRENGTH 9.0
#define SSL_RADIUS 8.0
#define GI_TAPS 2
#define GI_STRENGTH 2.0
#define GI_RADIUS 5.0
#define DOF_TAPS 2
#define DOF_STRENGTH 1.2
#define DOF_RADIUS 0.01
#define MB_STRENGTH 0.6
#define MB_MAX 0.03
#define BLOOM_TAPS 12
#define BLOOM_STRENGTH 0.3
#define BLOOM_RADIUS 0.03
#define BLOOM_THRESH 3.0
#define GODRAYS
#define GODRAY_STEPS 12
#define GODRAY_STRENGTH 0.3
#define EXPOSURE 0.36
#define AUTO_EXPOSURE
#define SAT 1.2
#define VIBRANCE 0.45
#define CONTRAST 0.3
#define VIGN 0.4
#define SHADOW_TINT vec3(1.0)
#define HIGH_TINT vec3(1.0)
#define GRADE_AMT 0.0
#define LIFT 0.0
#define LIFT_COL vec3(0.2, 0.18, 0.2)
#define SHARPEN_ON
#define SHARPEN 0.3
#define FXAA_ON
#define GBUF_ON
#ifndef SSL_TAPS
#define SSL_TAPS 12
#endif
#ifndef SSL_STRENGTH
#define SSL_STRENGTH 9.0
#endif
#ifndef SSL_RADIUS
#define SSL_RADIUS 8.0
#endif
varying vec2 texcoord;
uniform sampler2D colortex0;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform float viewWidth;
uniform float viewHeight;
vec3 vpAt(vec2 uv, float d) {
    vec4 p = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);
    return p.xyz / p.w;
}
void main() {
    vec3 col = texture2D(colortex0, texcoord).rgb;
    float d = texture2D(depthtex0, texcoord).r;
    vec3 albG = texture2D(colortex3, texcoord).rgb;
    if (d >= 1.0 || d < 0.56 || dot(albG, vec3(1.0)) < 0.001) { gl_FragData[0] = vec4(col, 1.0); return; }
    vec3 P = vpAt(texcoord, d);
    float dist = length(P);
    float aspect = viewWidth / viewHeight;
    float r = clamp(SSL_RADIUS / (dist * 1.4), 0.004, 0.2);
    float ign = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    float rot = ign * 6.2831853;
    vec3 acc = vec3(0.0);
    for (int i = 0; i < SSL_TAPS; i++) {
        float k = (float(i) + 0.5) / float(SSL_TAPS);
        float a = float(i) * 2.39996 + rot;
        vec2 uv = clamp(texcoord + vec2(cos(a), sin(a)) * sqrt(k) * r * vec2(1.0 / aspect, 1.0), vec2(0.001), vec2(0.999));
        vec3 e = texture2D(colortex2, uv).rgb;
        if (dot(e, vec3(1.0)) > 0.02) {
            vec3 dv = vpAt(uv, texture2D(depthtex0, uv).r) - P;
            float d2 = dot(dv, dv);
            acc += e * (1.0 / (1.0 + d2 * 0.3)) * step(d2, SSL_RADIUS * SSL_RADIUS);
        }
    }
    col += pow(albG, vec3(2.2)) * (acc / float(SSL_TAPS)) * SSL_STRENGTH;
    gl_FragData[0] = vec4(col, 1.0);
}
