Solstice Vivid

A stylized take on Medium: richer colors, teal water and livelier grass and leaves.

Install: put the .zip (do not unzip) in .minecraft/shaderpacks, then pick it in Video Settings > Shaders. Needs Iris or OptiFine.
Most options can also be changed in-game under Shader Options.
