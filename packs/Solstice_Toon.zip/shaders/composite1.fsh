#version 120
#define SKY_CLOUDS 1
#define CLOUD_OCT 3
#define SKY_CIRRUS 0
#define SKY_STARS 1
#define SKY_AURORA 0
#define SKY_TINT vec3(1.0, 1.0, 1.0)
#define SKY_VIVID 0
#define MOON_DETAIL 1
#define SUN_STRENGTH 0.8
#define SUN_COLOR vec3(1.0, 1.0, 1.0)
#define MOON_STRENGTH 1.0
#define AMB_STRENGTH 1.15
#define AMB_SAT 0.65
#define BOUNCE_STRENGTH 1.0
#define TORCH_STRENGTH 1.0
#define TORCH_NEAR vec3(1.0, 0.5, 0.16)
#define TORCH_FAR vec3(1.0, 0.22, 0.04)
#define EMISSIVE_STRENGTH 0.65
#define RIM_STRENGTH 0.3
#define FOLIAGE_GLOW 1.0
#define BLOCK_VARIATION 1.0
#define HELD_LIGHT 1.0
#define SHINY_STRENGTH 1.0
#define WET_STRENGTH 1.0
#define SHADOWS 1
#define SHADOW_TAPS 6
#define SHADOW_RAD 1.2
#define CLOUD_SHADOWS 0
#define FOG_DENSITY 0.0009
#define WAVES_EXTRA 0
#define WATER_NORMALS 1
#define WATER_COL vec3(0.039, 0.165, 0.184)
#define WATER_SPEC 6.0
#define SWAY_PLANT 0.06
#define SWAY_LEAF 0.025
#define AO_TAPS 2
#define AO_STRENGTH 0.6
#define SSL_TAPS 2
#define SSL_STRENGTH 9.0
#define SSL_RADIUS 8.0
#define GI_TAPS 2
#define GI_STRENGTH 2.0
#define GI_RADIUS 5.0
#define DOF_TAPS 2
#define DOF_STRENGTH 1.2
#define DOF_RADIUS 0.01
#define MB_STRENGTH 0.6
#define MB_MAX 0.03
#define BLOOM_TAPS 8
#define BLOOM_STRENGTH 0.2
#define BLOOM_RADIUS 0.03
#define BLOOM_THRESH 3.0
#define EXPOSURE 0.36
#define AUTO_EXPOSURE
#define SAT 1.25
#define VIBRANCE 0.3
#define CONTRAST 0.15
#define VIGN 0.4
#define SHADOW_TINT vec3(1.0)
#define HIGH_TINT vec3(1.0)
#define GRADE_AMT 0.0
#define LIFT 0.0
#define LIFT_COL vec3(0.2, 0.18, 0.2)
#define FXAA_ON
#define POSTERIZE
#define POSTERIZE_LEVELS 5.0
#define OUTLINE_ON
#define OUTLINE_STRENGTH 1.0
#define GBUF_ON
#ifndef OUTLINE_WIDTH
#define OUTLINE_WIDTH 1.0
#endif
#ifndef OUTLINE_DEPTH
#define OUTLINE_DEPTH 0.04
#endif
#ifndef OUTLINE_STRENGTH
#define OUTLINE_STRENGTH 0.9
#endif
#ifndef OUTLINE_COLOR
#define OUTLINE_COLOR vec3(0.02, 0.015, 0.03)
#endif
varying vec2 texcoord;
uniform sampler2D colortex0;
uniform sampler2D colortex4;
uniform sampler2D depthtex0;
uniform float near;
uniform float far;
uniform float viewWidth;
uniform float viewHeight;
float linD(float d) { return 2.0 * near * far / (far + near - (d * 2.0 - 1.0) * (far - near)); }
void main() {
    vec3 col = texture2D(colortex0, texcoord).rgb;
    float d = texture2D(depthtex0, texcoord).r;
    if (d < 0.56) { gl_FragData[0] = vec4(col, 1.0); return; }
    vec2 px = OUTLINE_WIDTH / vec2(viewWidth, viewHeight);
    float z0 = linD(d);
    vec3 n0 = texture2D(colortex4, texcoord).rgb * 2.0 - 1.0;
    float edge = 0.0;
    for (int i = 0; i < 4; i++) {
        vec2 o = i == 0 ? vec2(px.x, 0.0) : (i == 1 ? vec2(-px.x, 0.0) : (i == 2 ? vec2(0.0, px.y) : vec2(0.0, -px.y)));
        float z1 = linD(texture2D(depthtex0, texcoord + o).r);
        edge = max(edge, step(OUTLINE_DEPTH, abs(z1 - z0) / max(z0, 0.5)));
        vec3 n1 = texture2D(colortex4, texcoord + o).rgb * 2.0 - 1.0;
        if (dot(n1, n1) > 0.1 && dot(n0, n0) > 0.1) edge = max(edge, step(0.35, 1.0 - dot(normalize(n0), normalize(n1))));
    }
    edge *= 1.0 - smoothstep(60.0, 150.0, z0);
    col = mix(col, OUTLINE_COLOR, edge * OUTLINE_STRENGTH);
    gl_FragData[0] = vec4(col, 1.0);
}
