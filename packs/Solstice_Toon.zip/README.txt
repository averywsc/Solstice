Solstice Toon

Hand-drawn look: banded cartoon shading, bold ink outlines and bright flat colors.

Install: put the .zip (do not unzip) in .minecraft/shaderpacks, then pick it in Video Settings > Shaders. Needs Iris or OptiFine.
Most options can also be changed in-game under Shader Options.
