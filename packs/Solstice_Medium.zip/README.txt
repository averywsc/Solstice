Solstice Medium

Shadows at 1024 resolution, procedural clouds, light shafts and colored light spill from glowing blocks.

Install: put the .zip (do not unzip) in .minecraft/shaderpacks, then pick it in Video Settings > Shaders. Needs Iris or OptiFine.
Most options can also be changed in-game under Shader Options.
