Solstice Lite

A light pack with a physically based sky and sun rays but no shadow pass. Good for weaker GPUs.

Install: put the .zip (do not unzip) in .minecraft/shaderpacks, then pick it in Video Settings > Shaders. Needs Iris or OptiFine.
Most options can also be changed in-game under Shader Options.
