Solstice High

Smooth shadows, cloud shadows, light shafts, reflections in water, ambient occlusion and bounce light.

Install: put the .zip (do not unzip) in .minecraft/shaderpacks, then pick it in Video Settings > Shaders. Needs Iris or OptiFine.
Most options can also be changed in-game under Shader Options.
