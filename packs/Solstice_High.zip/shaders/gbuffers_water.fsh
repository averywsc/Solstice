#version 120
#define SKY_CLOUDS 1
#define CLOUD_OCT 4
#define SKY_CIRRUS 1
#define SKY_STARS 2
#define SKY_AURORA 0
#define SKY_TINT vec3(1.0, 1.0, 1.0)
#define SKY_VIVID 0
#define MOON_DETAIL 1
#define SUN_STRENGTH 0.8
#define SUN_COLOR vec3(1.0, 1.0, 1.0)
#define MOON_STRENGTH 1.0
#define AMB_STRENGTH 1.0
#define AMB_SAT 0.65
#define BOUNCE_STRENGTH 1.0
#define TORCH_STRENGTH 1.0
#define TORCH_NEAR vec3(1.0, 0.5, 0.16)
#define TORCH_FAR vec3(1.0, 0.22, 0.04)
#define EMISSIVE_STRENGTH 0.65
#define RIM_STRENGTH 1.0
#define FOLIAGE_GLOW 1.0
#define BLOCK_VARIATION 1.0
#define HELD_LIGHT 1.0
#define SHINY_STRENGTH 1.0
#define WET_STRENGTH 1.0
#define SHADOWS 2
#define SHADOW_TAPS 10
#define SHADOW_RAD 2.2
#define CLOUD_SHADOWS 1
#define FOG_DENSITY 0.0009
#define VOL_LIGHT
#define VOL_STEPS 8
#define VOL_RANGE 80
#define VOL_DENSITY 0.012
#define VOL_STRENGTH 1.0
#define WAVES_EXTRA 0
#define WATER_NORMALS 1
#define WATER_COL vec3(0.039, 0.165, 0.184)
#define WATER_SPEC 6.0
#define SSR
#define SSR_STEPS 24
#define SWAY_PLANT 0.06
#define SWAY_LEAF 0.025
#define AO_TAPS 8
#define AO_STRENGTH 0.6
#define SSL_TAPS 16
#define SSL_STRENGTH 9.0
#define SSL_RADIUS 8.0
#define GI_TAPS 16
#define GI_STRENGTH 2.0
#define GI_RADIUS 5.0
#define DOF_TAPS 2
#define DOF_STRENGTH 1.2
#define DOF_RADIUS 0.01
#define MB_STRENGTH 0.6
#define MB_MAX 0.03
#define BLOOM_TAPS 24
#define BLOOM_STRENGTH 0.3
#define BLOOM_RADIUS 0.03
#define BLOOM_THRESH 3.0
#define GODRAYS
#define GODRAY_STEPS 20
#define GODRAY_STRENGTH 0.3
#define EXPOSURE 0.36
#define AUTO_EXPOSURE
#define SAT 0.95
#define VIBRANCE 0.08
#define CONTRAST 0.15
#define VIGN 0.4
#define SHADOW_TINT vec3(1.0)
#define HIGH_TINT vec3(1.0)
#define GRADE_AMT 0.0
#define LIFT 0.0
#define LIFT_COL vec3(0.2, 0.18, 0.2)
#define SHARPEN_ON
#define SHARPEN 0.3
#define FXAA_ON
#define GBUF_ON
#ifndef SKY_TINT
#define SKY_TINT vec3(1.0)
#endif
/* DRAWBUFFERS:01234 */
#ifndef WAVES_EXTRA
#define WAVES_EXTRA 0
#endif
#ifndef WATER_NORMALS
#define WATER_NORMALS 1
#endif
#ifndef WATER_COL
#define WATER_COL vec3(0.02, 0.10, 0.12)
#endif
#ifndef WATER_SPEC
#define WATER_SPEC 6.0
#endif
#ifndef SUN_STRENGTH
#define SUN_STRENGTH 1.0
#endif
#ifndef SUN_COLOR
#define SUN_COLOR vec3(1.0)
#endif
#ifndef MOON_STRENGTH
#define MOON_STRENGTH 1.0
#endif
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPos;
varying vec3 worldPos;
varying float isWater;
varying vec3 vSunTrans;
varying vec3 vSkyAmb;

uniform sampler2D texture;
uniform mat4 gbufferModelView;
uniform vec3 shadowLightPosition;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform int moonPhase;

float waveH(vec2 p, float t) {
    return sin(p.x * 1.3 + t * 1.2) * 0.5
         + sin(p.y * 1.7 - t * 0.9 + p.x * 0.4) * 0.35
         + sin((p.x + p.y) * 2.9 + t * 1.9) * 0.15
#if WAVES_EXTRA
         + sin(p.x * 4.7 - p.y * 3.1 + t * 2.7) * 0.07
         + sin(p.y * 6.3 + t * 3.3) * 0.04
#endif
         ;
}


const vec3 BR = vec3(5.8e-3, 13.5e-3, 33.1e-3);
const float BM = 0.01;
const vec3 BO = vec3(0.65e-3, 1.881e-3, 0.085e-3);
vec3 twilightFill(float h, float cs, float sh) {
    float e = (sh + 0.06) / 0.10;
    float tw = exp(-e * e);
    float side = 0.35 + 0.65 * pow(max(cs, 0.0), 2.0);
    float hz = pow(1.0 - clamp(abs(h), 0.0, 1.0), 3.0);
    vec3 c = mix(vec3(0.07, 0.1, 0.28), vec3(0.95, 0.38, 0.48), hz * side);
    return c * tw * 0.35;
}
vec3 sunTrans(float sh) {
    if (sh < 0.0) return vec3(0.0);
    float R = 6371.0;
    float alt0 = 0.002;
    float sx = sqrt(max(1.0 - sh * sh, 0.0));
    float b = (R + alt0) * sh;
    float tl = -b + sqrt(b * b + (100.0 - alt0) * (2.0 * R + 100.0 + alt0));
    float odr = 0.0; float odm = 0.0; float odo = 0.0;
    for (int j = 0; j < 8; j++) {
        float u = (float(j) + 0.5) / 8.0;
        float d = tl * u * u;
        float w = tl * 2.0 * u / 8.0;
        vec3 Q = vec3(sx * d, R + alt0 + sh * d, 0.0);
        float a = max(length(Q) - R, 0.0);
        odr += exp(-a / 8.0) * w;
        odm += exp(-a / 1.2) * w;
        odo += max(0.0, 1.0 - abs(a - 25.0) / 15.0) * w;
    }
    return exp(-(BR * odr + BM * 1.1 * odm + BO * odo));
}
float effSh(float sh) {
    return sh < 0.0 ? sh : mix(sh * 0.08, sh, smoothstep(0.30, 0.75, sh));
}
float goldF(float shR) {
    return (1.0 - smoothstep(0.15, 0.6, shR)) * smoothstep(-0.05, 0.08, shR);
}
vec3 goldTint(float shR) {
    return mix(vec3(1.0), vec3(1.12, 0.92, 0.64), goldF(shR));
}
vec3 goldenFill(float h, float cs, float shR) {
    float gw = smoothstep(0.0, 0.08, shR) * (1.0 - smoothstep(0.15, 0.6, shR)) * 2.0;
    float hz = pow(1.0 - clamp(abs(h), 0.0, 1.0), 3.0);
    vec3 c = mix(vec3(0.34, 0.16, 0.09), vec3(1.7, 0.75, 0.3), hz);
    return c * gw * (0.4 + 0.6 * pow(max(cs, 0.0), 2.0));
}
vec3 sunLight(float shR) {
    float g = goldF(shR);
    vec3 neutral = sunTrans(shR) * 3.4;
    vec3 golden = vec3(3.4, 1.05, 0.32) * smoothstep(0.0, 0.06, shR);
    return mix(neutral, golden, g);
}

vec3 skyF(vec3 dir, vec3 sunDir, vec3 upN) {
    float shR = dot(sunDir, upN);
    if (shR < -0.32) return vec3(0.0);
    float sh = effSh(shR);
    float h = max(dot(dir, upN), 0.0005);
    float cs = clamp(dot(dir, sunDir), -1.0, 1.0);
    float vx = sqrt(max(1.0 - h * h, 0.0));
    float sx = (cs - h * sh) / max(vx, 0.0001);
    float sz = sqrt(max(1.0 - sh * sh - sx * sx, 0.0));
    float R = 6371.0;
    float alt0 = 0.002;
    float b = (R + alt0) * h;
    float tm = min(-b + sqrt(b * b + (100.0 - alt0) * (2.0 * R + 100.0 + alt0)), 40.0);
    float ds = tm / float(6);
    float odr = 0.0; float odm = 0.0; float odo = 0.0;
    vec3 sc = vec3(0.0);
    float pr = 0.0596831 * (1.0 + cs * cs) * 1.4;
    float pm = 0.119366 * (0.36 * (1.0 + cs * cs)) / (2.64 * pow(1.64 - 1.6 * cs, 1.5));
    for (int i = 0; i < 6; i++) {
        float t = ds * (float(i) + 0.5);
        float px = vx * t;
        float py = R + alt0 + h * t;
        float len = sqrt(px * px + py * py);
        float alt = (px * px + (alt0 + h * t) * (2.0 * R + alt0 + h * t)) / (len + R);
        float dr = exp(-alt / 8.0);
        float dm = exp(-alt / 1.2);
        float dzo = max(0.0, 1.0 - abs(alt - 25.0) / 15.0);
        odr += dr * ds; odm += dm * ds; odo += dzo * ds;
        float b2 = px * sx + py * sh;
        if (b2 < 0.0 && b2 * b2 - alt * (len + R) > 0.0) continue;
        float tl = -b2 + sqrt(max(b2 * b2 - (alt - 100.0) * (len + 6471.0), 0.0));
        float lr = 0.0; float lm = 0.0; float lo = 0.0;
        for (int j = 0; j < 3; j++) {
            float u = (float(j) + 0.5) / float(3);
            float d = tl * u * u;
            float w = tl * 2.0 * u / float(3);
            vec3 Q = vec3(px + sx * d, py + sh * d, sz * d);
            float a = max(length(Q) - R, 0.0);
            lr += exp(-a / 8.0) * w;
            lm += exp(-a / 1.2) * w;
            lo += max(0.0, 1.0 - abs(a - 25.0) / 15.0) * w;
        }
        vec3 att = exp(-(BR * (odr + lr) + BM * 1.1 * (odm + lm) + BO * (odo + lo)));
        sc += att * (BR * dr * pr + BM * dm * pm) * ds;
    }
    vec3 outc = (sc * 22.0 + twilightFill(h, cs, shR) + goldenFill(h, cs, shR)) * goldTint(shR);
    outc.g = min(outc.g, max(outc.r, outc.b) * 1.04);
    return outc * SKY_TINT;
}

void main() {
    vec4 tex = texture2D(texture, texcoord);
    vec3 albedo = pow(tex.rgb * glcolor.rgb, vec3(2.2));
    float skyL = clamp((lmcoord.y - 0.031) / 0.9375, 0.0, 1.0);
    skyL *= skyL;
    float blkL = pow(clamp((lmcoord.x - 0.031) / 0.9375, 0.0, 1.0), 2.5);

    float sunH = dot(normalize(sunPosition), normalize(upPosition));
    float lh = abs(sunH);
    vec3 sunCol = vSunTrans * 3.4 * SUN_STRENGTH * SUN_COLOR;
    vec3 moonCol = vec3(0.35, 0.5, 0.9) * 0.35 * (0.25 + 0.75 * (0.5 + 0.5 * cos(float(moonPhase) * 0.7853982)));
    vec3 lightCol = (sunH > 0.0 ? sunCol : moonCol) * smoothstep(0.0, 0.1, lh) * (1.0 - 0.85 * rainStrength);
    vec3 sc = vSkyAmb;
    vec3 amb = mix(vec3(dot(sc, vec3(0.333))), sc, 0.55) * 0.9 + vec3(0.012, 0.016, 0.035);
    vec3 L = normalize(shadowLightPosition);

    if (isWater < 0.5) {
        // glass, ice, etc.
        vec3 n = normalize(normal);
        float ndl = max(dot(n, L), 0.0);
        vec3 col = albedo * (amb * skyL + lightCol * ndl * smoothstep(0.2, 0.6, skyL) + vec3(1.0, 0.55, 0.25) * blkL * 1.4);
        gl_FragData[0] = vec4(col, tex.a * glcolor.a);
        gl_FragData[1] = vec4(0.0, 0.0, 0.0, 1.0);
#ifdef GBUF_ON
        gl_FragData[2] = vec4(0.0, 0.0, 0.0, 1.0);
        gl_FragData[3] = vec4(0.0, 0.0, 0.0, 1.0);
        gl_FragData[4] = vec4(0.0, 0.0, 0.0, 1.0);
#endif
        return;
    }

#if WATER_NORMALS
    // wave normal
    float e = 0.06;
    float h0 = waveH(worldPos.xz, frameTimeCounter);
    float hx = waveH(worldPos.xz + vec2(e, 0.0), frameTimeCounter);
    float hz = waveH(worldPos.xz + vec2(0.0, e), frameTimeCounter);
    vec3 wn = normalize(vec3(-(hx - h0) / e * 0.12, 1.0, -(hz - h0) / e * 0.12));
    vec3 n = normalize(mat3(gbufferModelView) * wn);
#else
    vec3 n = normalize(normal);
#endif

    vec3 V = -normalize(viewPos);
    float fres = 0.03 + 0.97 * pow(1.0 - max(dot(n, V), 0.0), 5.0);

    vec3 R = reflect(-V, n);
    float up = dot(R, normalize(upPosition));
    vec3 skyRef = (skyF(R, normalize(sunPosition), normalize(upPosition)) + vec3(0.003, 0.005, 0.011)) * skyL;

    vec3 waterCol = WATER_COL;
    vec3 body = waterCol * (amb * skyL + lightCol * 0.25 * skyL + vec3(1.0, 0.55, 0.25) * blkL);

    vec3 H = normalize(L + V);
    float spec = pow(max(dot(n, H), 0.0), 220.0) * WATER_SPEC * skyL;
    float spk = fract(sin(dot(floor(worldPos.xz * 5.0 + vec2(frameTimeCounter * 0.6, 0.0)), vec2(12.9898, 78.233))) * 43758.5453);
    spec *= 0.35 + 3.0 * pow(spk, 5.0);
    vec3 col = mix(body, skyRef, fres) + lightCol * spec;
    col += vec3(0.0, 0.35, 0.3) * lightCol * pow(max(dot(normalize(viewPos), L), 0.0), 6.0) * (1.0 - fres) * (0.4 + 4.0 * (1.0 - dot(n, normalize(upPosition)))) * skyL * 0.25;

    float alpha = clamp(0.12 + fres * 0.9 + spec * 0.2, 0.0, 1.0);
    gl_FragData[0] = vec4(col, alpha);
    gl_FragData[1] = vec4(1.0, n.x * 0.5 + 0.5, n.y * 0.5 + 0.5, 1.0);
#ifdef GBUF_ON
    gl_FragData[2] = vec4(0.0, 0.0, 0.0, 1.0);
    gl_FragData[3] = vec4(0.0, 0.0, 0.0, 1.0);
    gl_FragData[4] = vec4(0.0, 0.0, 0.0, 1.0);
#endif
}
