#version 120
#define SKY_CLOUDS 1
#define CLOUD_OCT 4
#define SKY_CIRRUS 1
#define SKY_STARS 2
#define SKY_AURORA 0
#define SKY_TINT vec3(1.0, 1.0, 1.0)
#define SKY_VIVID 0
#define MOON_DETAIL 1
#define SUN_STRENGTH 0.8
#define SUN_COLOR vec3(1.0, 1.0, 1.0)
#define MOON_STRENGTH 1.0
#define AMB_STRENGTH 1.0
#define AMB_SAT 0.65
#define BOUNCE_STRENGTH 1.0
#define TORCH_STRENGTH 1.0
#define TORCH_NEAR vec3(1.0, 0.5, 0.16)
#define TORCH_FAR vec3(1.0, 0.22, 0.04)
#define EMISSIVE_STRENGTH 0.65
#define RIM_STRENGTH 1.0
#define FOLIAGE_GLOW 1.0
#define BLOCK_VARIATION 1.0
#define HELD_LIGHT 1.0
#define SHINY_STRENGTH 1.0
#define WET_STRENGTH 1.0
#define SHADOWS 2
#define SHADOW_TAPS 10
#define SHADOW_RAD 2.2
#define CLOUD_SHADOWS 1
#define FOG_DENSITY 0.0009
#define VOL_LIGHT
#define VOL_STEPS 8
#define VOL_RANGE 80
#define VOL_DENSITY 0.012
#define VOL_STRENGTH 1.0
#define WAVES_EXTRA 0
#define WATER_NORMALS 1
#define WATER_COL vec3(0.039, 0.165, 0.184)
#define WATER_SPEC 6.0
#define SSR
#define SSR_STEPS 24
#define SWAY_PLANT 0.06
#define SWAY_LEAF 0.025
#define AO_TAPS 8
#define AO_STRENGTH 0.6
#define SSL_TAPS 16
#define SSL_STRENGTH 9.0
#define SSL_RADIUS 8.0
#define GI_TAPS 16
#define GI_STRENGTH 2.0
#define GI_RADIUS 5.0
#define DOF_TAPS 2
#define DOF_STRENGTH 1.2
#define DOF_RADIUS 0.01
#define MB_STRENGTH 0.6
#define MB_MAX 0.03
#define BLOOM_TAPS 24
#define BLOOM_STRENGTH 0.3
#define BLOOM_RADIUS 0.03
#define BLOOM_THRESH 3.0
#define GODRAYS
#define GODRAY_STEPS 20
#define GODRAY_STRENGTH 0.3
#define EXPOSURE 0.36
#define AUTO_EXPOSURE
#define SAT 0.95
#define VIBRANCE 0.08
#define CONTRAST 0.15
#define VIGN 0.4
#define SHADOW_TINT vec3(1.0)
#define HIGH_TINT vec3(1.0)
#define GRADE_AMT 0.0
#define LIFT 0.0
#define LIFT_COL vec3(0.2, 0.18, 0.2)
#define SHARPEN_ON
#define SHARPEN 0.3
#define FXAA_ON
#define GBUF_ON
#ifndef EXPOSURE
#define EXPOSURE 0.7
#endif
#ifndef SHADOW_TINT
#define SHADOW_TINT vec3(1.0)
#endif
#ifndef HIGH_TINT
#define HIGH_TINT vec3(1.0)
#endif
#ifndef GRADE_AMT
#define GRADE_AMT 0.0
#endif
#ifndef SAT
#define SAT 0.95
#endif
#ifndef CONTRAST
#define CONTRAST 0.15
#endif
#ifndef VIGN
#define VIGN 0.4
#endif
#ifndef LIFT
#define LIFT 0.0
#endif
#ifndef LIFT_COL
#define LIFT_COL vec3(0.0)
#endif
#ifndef GRAIN_AMT
#define GRAIN_AMT 0.04
#endif
#ifndef CHROMA_AMT
#define CHROMA_AMT 0.004
#endif
#ifndef SHARPEN
#define SHARPEN 0.3
#endif
#ifndef VIBRANCE
#define VIBRANCE 0.08
#endif
#ifndef LETTERBOX_RATIO
#define LETTERBOX_RATIO 2.39
#endif
#ifndef PIXEL_SIZE
#define PIXEL_SIZE 4.0
#endif
#ifndef SCAN_SIZE
#define SCAN_SIZE 3.0
#endif
#ifndef POSTERIZE_LEVELS
#define POSTERIZE_LEVELS 5.0
#endif
#ifndef MONO_AMT
#define MONO_AMT 1.0
#endif
varying vec2 texcoord;
uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTimeCounter;
uniform ivec2 eyeBrightnessSmooth;
uniform vec3 sunPosition;
uniform vec3 upPosition;
vec3 aces(vec3 x) {
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}
float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
float fxL(vec3 c) { float l = dot(c, vec3(0.299, 0.587, 0.114)); return l / (1.0 + l); }
vec3 fxaa(vec2 uv, vec2 px) {
    vec3 cNW = texture2D(colortex0, uv + vec2(-px.x, -px.y)).rgb;
    vec3 cNE = texture2D(colortex0, uv + vec2(px.x, -px.y)).rgb;
    vec3 cSW = texture2D(colortex0, uv + vec2(-px.x, px.y)).rgb;
    vec3 cSE = texture2D(colortex0, uv + vec2(px.x, px.y)).rgb;
    vec3 cM = texture2D(colortex0, uv).rgb;
    float lNW = fxL(cNW); float lNE = fxL(cNE); float lSW = fxL(cSW); float lSE = fxL(cSE); float lM = fxL(cM);
    float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
    vec2 dir = vec2(-((lNW + lNE) - (lSW + lSE)), (lNW + lSW) - (lNE + lSE));
    float dirReduce = max((lNW + lNE + lSW + lSE) * 0.03125, 0.0078125);
    float rcp = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = clamp(dir * rcp, vec2(-8.0), vec2(8.0)) * px;
    vec3 rgbA = 0.5 * (texture2D(colortex0, uv + dir * (1.0 / 3.0 - 0.5)).rgb + texture2D(colortex0, uv + dir * (2.0 / 3.0 - 0.5)).rgb);
    vec3 rgbB = rgbA * 0.5 + 0.25 * (texture2D(colortex0, uv + dir * -0.5).rgb + texture2D(colortex0, uv + dir * 0.5).rgb);
    float lB = fxL(rgbB);
    return (lB < lMin || lB > lMax) ? rgbA : rgbB;
}
void main() {
    vec2 uv = texcoord;
    float aspect = viewWidth / viewHeight;
#ifdef PIXELATE
    {
        vec2 rs = vec2(viewWidth, viewHeight);
        uv = (floor(uv * rs / PIXEL_SIZE) + 0.5) * PIXEL_SIZE / rs;
    }
#endif
#ifdef LETTERBOX
    float barH = max(0.0, 0.5 * (1.0 - aspect / LETTERBOX_RATIO));
    if (uv.y < barH || uv.y > 1.0 - barH) { gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0); return; }
#endif
    vec3 c;
#if defined(FXAA_ON) && !defined(PIXELATE)
    c = fxaa(uv, 1.0 / vec2(viewWidth, viewHeight));
#else
    c = texture2D(colortex0, uv).rgb;
#endif
#ifdef CHROMA
    {
        vec2 dv = (uv - 0.5) * CHROMA_AMT;
        vec3 cen = texture2D(colortex0, uv).rgb;
        c += vec3(texture2D(colortex0, uv + dv).r - cen.r, 0.0, texture2D(colortex0, uv - dv).b - cen.b);
    }
#endif
#if defined(SHARPEN_ON) && !defined(PIXELATE)
    {
        vec2 px = 1.0 / vec2(viewWidth, viewHeight);
        vec3 bl4 = (texture2D(colortex0, uv + vec2(px.x, 0.0)).rgb + texture2D(colortex0, uv - vec2(px.x, 0.0)).rgb
                  + texture2D(colortex0, uv + vec2(0.0, px.y)).rgb + texture2D(colortex0, uv - vec2(0.0, px.y)).rgb) * 0.25;
        c += (c - bl4) * SHARPEN / (1.0 + dot(c, vec3(0.333)) * 0.6);
        c = max(c, vec3(0.0));
    }
#endif
    float expo = EXPOSURE;
#ifdef AUTO_EXPOSURE
    float dayf = smoothstep(-0.25, 0.1, dot(normalize(sunPosition), normalize(upPosition)));
    float eb = clamp(float(eyeBrightnessSmooth.y) / 240.0, 0.0, 1.0);
    expo *= mix(1.7, mix(2.0, 0.9, dayf), eb);
    {
        float shg = dot(normalize(sunPosition), normalize(upPosition));
        expo *= 1.0 + 0.35 * (1.0 - smoothstep(0.15, 0.6, shg)) * smoothstep(-0.05, 0.08, shg);
    }
    float sunFace = max(-normalize(sunPosition).z, 0.0);
    expo *= 1.0 - 0.28 * pow(sunFace, 8.0) * dayf;
#endif
    c = aces(c * expo);
    c = pow(c, vec3(1.0 / 2.2));
    float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(c, c * SHADOW_TINT, (1.0 - l) * GRADE_AMT);
    c = mix(c, c * HIGH_TINT, l * GRADE_AMT);
    l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(vec3(l), c, SAT);
    {
        float mxc = max(c.r, max(c.g, c.b));
        float mnc = min(c.r, min(c.g, c.b));
        float sat0 = (mxc - mnc) / (mxc + 0.0001);
        c = mix(vec3(l), c, 1.0 + VIBRANCE * (1.0 - sat0));
    }
    c = mix(c, c * c * (3.0 - 2.0 * c), CONTRAST);
    c = c * (1.0 - LIFT) + LIFT_COL * LIFT;
#ifdef POSTERIZE
    {
        float lp = dot(c, vec3(0.2126, 0.7152, 0.0722));
        float lq = floor(lp * POSTERIZE_LEVELS + 0.5) / POSTERIZE_LEVELS;
        c *= lq / max(lp, 0.02);
    }
#endif
#ifdef MONO
    {
        float lm = dot(c, vec3(0.2126, 0.7152, 0.0722));
#ifdef MONO_ACCENT
        float red = clamp((c.r - max(c.g, c.b)) * 5.0, 0.0, 1.0);
        c = mix(vec3(lm), c, max(red, 1.0 - MONO_AMT));
#else
        c = mix(c, vec3(lm), MONO_AMT);
#endif
    }
#endif
    vec2 q = uv - 0.5;
    c *= 1.0 - dot(q, q) * VIGN;
#ifdef SCANLINES
    c *= 0.86 + 0.14 * sin(gl_FragCoord.y * 6.2831853 / SCAN_SIZE);
#endif
#ifdef GRAIN
    float g = hash12(uv * vec2(viewWidth, viewHeight) + fract(frameTimeCounter) * 91.7) - 0.5;
    c += g * GRAIN_AMT * (1.2 - l);
#endif
    float dth = hash12(gl_FragCoord.xy + fract(frameTimeCounter) * 61.0) + hash12(gl_FragCoord.yx * 1.37 + fract(frameTimeCounter) * 29.0) - 1.0;
    c += dth / 255.0;
    gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
