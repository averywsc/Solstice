Solstice Dream

Dreamlike soft focus with a pastel grade and glowing light. It fills the whole screen. Optional cinema bars (Shader Options) crop to a wider ratio (2.39:1 by default).

Install: put the .zip (do not unzip) in .minecraft/shaderpacks, then pick it in Video Settings > Shaders. Needs Iris or OptiFine.
Most options can also be changed in-game under Shader Options.
