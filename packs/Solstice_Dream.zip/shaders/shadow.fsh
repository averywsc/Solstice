#version 120
#define SKY_CLOUDS 1
#define CLOUD_OCT 4
#define SKY_CIRRUS 1
#define SKY_STARS 2
#define SKY_AURORA 1
#define SKY_TINT vec3(1.0, 1.0, 1.0)
#define SKY_VIVID 1
#define MOON_DETAIL 1
#define SUN_STRENGTH 0.8
#define SUN_COLOR vec3(1.0, 1.0, 1.0)
#define MOON_STRENGTH 1.0
#define AMB_STRENGTH 1.0
#define AMB_SAT 0.65
#define BOUNCE_STRENGTH 1.0
#define TORCH_STRENGTH 1.0
#define TORCH_NEAR vec3(1.0, 0.5, 0.16)
#define TORCH_FAR vec3(1.0, 0.22, 0.04)
#define EMISSIVE_STRENGTH 0.65
#define RIM_STRENGTH 1.0
#define FOLIAGE_GLOW 1.0
#define BLOCK_VARIATION 1.0
#define HELD_LIGHT 1.0
#define SHINY_STRENGTH 1.0
#define WET_STRENGTH 1.0
#define SHADOWS 2
#define SHADOW_TAPS 10
#define SHADOW_RAD 2.2
#define CLOUD_SHADOWS 1
#define FOG_DENSITY 0.0022
#define VOL_LIGHT
#define VOL_STEPS 12
#define VOL_RANGE 96
#define VOL_DENSITY 0.012
#define VOL_STRENGTH 1.0
#define WAVES_EXTRA 1
#define WATER_NORMALS 1
#define WATER_COL vec3(0.0, 0.2, 0.251)
#define WATER_SPEC 6.0
#define SSR
#define SSR_STEPS 24
#define SWAY_PLANT 0.06
#define SWAY_LEAF 0.025
#define AO_TAPS 8
#define AO_STRENGTH 0.6
#define SSL_TAPS 16
#define SSL_STRENGTH 9.0
#define SSL_RADIUS 8.0
#define GI_TAPS 16
#define GI_STRENGTH 2.0
#define GI_RADIUS 5.0
#define DOF_TAPS 14
#define DOF_STRENGTH 1.0
#define DOF_RADIUS 0.01
#define MB_STRENGTH 0.6
#define MB_MAX 0.03
#define BLOOM_TAPS 32
#define BLOOM_STRENGTH 0.4
#define BLOOM_RADIUS 0.03
#define BLOOM_THRESH 3.0
#define BLOOM_WIDE
#define BLOOM_WIDE_STRENGTH 0.35
#define GODRAYS
#define GODRAY_STEPS 20
#define GODRAY_STRENGTH 0.3
#define FLARE
#define FLARE_STRENGTH 0.1
#define ANAMORPHIC
#define ANAMORPHIC_STRENGTH 0.25
#define EXPOSURE 0.36
#define AUTO_EXPOSURE
#define SAT 1.15
#define VIBRANCE 0.4
#define CONTRAST 0.2
#define VIGN 0.9
#define SHADOW_TINT vec3(1.1, 0.85, 1.2)
#define HIGH_TINT vec3(0.9, 1.05, 1.15)
#define GRADE_AMT 0.7
#define LIFT 0.07
#define LIFT_COL vec3(0.4, 0.25, 0.55)
#define GRAIN
#define GRAIN_AMT 0.02
#define CHROMA
#define CHROMA_AMT 0.006
#define SHARPEN_ON
#define SHARPEN 0.3
#define FXAA_ON
#define GBUF_ON
const int shadowMapResolution = 2048;
const float shadowDistance = 120.0;
const float sunPathRotation = -25.0;
uniform sampler2D texture;
varying vec2 texcoord;
varying vec4 glcolor;
void main() {
    vec4 c = texture2D(texture, texcoord) * glcolor;
    if (c.a < 0.1) discard;
    gl_FragData[0] = c;
}
