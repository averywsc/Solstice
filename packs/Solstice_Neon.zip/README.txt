Solstice Neon

A permanent synthwave mood: magenta and cyan skies, pink torchlight, strong glow on lit blocks and a night-club grade.

Install: put the .zip (do not unzip) in .minecraft/shaderpacks, then pick it in Video Settings > Shaders. Needs Iris or OptiFine.
Most options can also be changed in-game under Shader Options.
