Solstice Retro

A chunky old-TV look: a low-resolution picture, scanlines, color fringing and punchy colors.

Install: put the .zip (do not unzip) in .minecraft/shaderpacks, then pick it in Video Settings > Shaders. Needs Iris or OptiFine.
Most options can also be changed in-game under Shader Options.
