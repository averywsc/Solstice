Solstice Cinematic

A film look: teal-and-orange grade, grain, light streaks and a soft lens glow. It fills the whole screen. If you turn on the optional cinema bars in Shader Options, the picture is cropped to a wider ratio (2.39:1 by default) and no longer fits a normal 16:9 screen.

Install: put the .zip (do not unzip) in .minecraft/shaderpacks, then pick it in Video Settings > Shaders. Needs Iris or OptiFine.
Most options can also be changed in-game under Shader Options.
