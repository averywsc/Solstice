Solstice Noir

Classic film noir: high contrast black and white with only reds kept in color, heavy grain and vignette.

Install: put the .zip (do not unzip) in .minecraft/shaderpacks, then pick it in Video Settings > Shaders. Needs Iris or OptiFine.
Most options can also be changed in-game under Shader Options.
