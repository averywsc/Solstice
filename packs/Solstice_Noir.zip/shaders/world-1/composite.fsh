#version 120
/* const int colortex0Format = RGBA16F; */
varying vec2 texcoord;
uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform vec3 fogColor;
uniform float far;
uniform int isEyeInWater;
uniform ivec2 eyeBrightnessSmooth;
void main() {
    vec3 col = texture2D(colortex0, texcoord).rgb;
    float d = texture2D(depthtex0, texcoord).r;
    vec4 p = gbufferProjectionInverse * vec4(texcoord * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);
    float dist = length(p.xyz / p.w);
    if (isEyeInWater == 1) {
        float f = 1.0 - exp(-dist * 0.09);
        col = mix(col * vec3(0.55, 0.85, 1.0), vec3(0.02, 0.2, 0.3), f);
    } else if (isEyeInWater == 2) {
        col = mix(col, vec3(0.9, 0.25, 0.02), 1.0 - exp(-dist * 0.8));
    } else if (d < 1.0) {
        float mist = 1.0 - exp(-dist * 0.01);
        float edge = smoothstep(far * 0.55, far * 0.98, dist);
        col = mix(col, pow(fogColor, vec3(2.2)), clamp(max(mist, edge), 0.0, 1.0));
    }
    gl_FragData[0] = vec4(col, 1.0);
}
