#version 120
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPos;
uniform sampler2D texture;
void main() {
    vec4 tex = texture2D(texture, texcoord);
    if (tex.a < 0.1) discard;
    vec3 albedo = pow(tex.rgb * glcolor.rgb, vec3(2.2));
    float blk = pow(clamp((lmcoord.x - 0.031) / 0.9375, 0.0, 1.0), 2.5);
    vec3 col = albedo * (vec3(0.52, 0.27, 0.2) + vec3(1.0, 0.55, 0.25) * blk * 1.6);
    col += albedo * smoothstep(0.93, 0.96, lmcoord.x) * 1.2;
    gl_FragData[0] = vec4(col, tex.a * glcolor.a);
}
