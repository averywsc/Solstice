#version 120
uniform sampler2D texture;
varying vec2 texcoord;
varying vec4 glcolor;
void main() {
    vec4 c = texture2D(texture, texcoord) * glcolor;
    c.rgb = pow(c.rgb, vec3(2.2)) * 1.6;
    gl_FragData[0] = c;
}
