#version 120
varying vec2 texcoord;
varying vec4 glcolor;
uniform sampler2D texture;
void main() {
    vec4 c = texture2D(texture, texcoord) * glcolor;
    c.rgb = pow(c.rgb, vec3(2.2)) * 3.0;
    gl_FragData[0] = c;
}
