#version 120
#define SKY_CLOUDS 1
#define CLOUD_OCT 4
#define SKY_CIRRUS 1
#define SKY_STARS 2
#define SKY_AURORA 0
#define SKY_TINT vec3(1.0, 1.0, 1.0)
#define SKY_VIVID 0
#define MOON_DETAIL 1
#define SUN_STRENGTH 0.8
#define SUN_COLOR vec3(1.0, 1.0, 1.0)
#define MOON_STRENGTH 1.0
#define AMB_STRENGTH 1.0
#define AMB_SAT 0.65
#define BOUNCE_STRENGTH 1.0
#define TORCH_STRENGTH 1.0
#define TORCH_NEAR vec3(1.0, 0.5, 0.16)
#define TORCH_FAR vec3(1.0, 0.22, 0.04)
#define EMISSIVE_STRENGTH 0.65
#define RIM_STRENGTH 1.0
#define FOLIAGE_GLOW 1.0
#define BLOCK_VARIATION 1.0
#define HELD_LIGHT 1.0
#define SHINY_STRENGTH 1.0
#define WET_STRENGTH 1.0
#define SHADOWS 2
#define SHADOW_TAPS 10
#define SHADOW_RAD 2.2
#define CLOUD_SHADOWS 1
#define FOG_DENSITY 0.0014
#define VOL_LIGHT
#define VOL_STEPS 8
#define VOL_RANGE 80
#define VOL_DENSITY 0.012
#define VOL_STRENGTH 1.0
#define WAVES_EXTRA 0
#define WATER_NORMALS 1
#define WATER_COL vec3(0.039, 0.165, 0.184)
#define WATER_SPEC 6.0
#define SSR
#define SSR_STEPS 24
#define SWAY_PLANT 0.06
#define SWAY_LEAF 0.025
#define AO_TAPS 8
#define AO_STRENGTH 0.6
#define SSL_TAPS 16
#define SSL_STRENGTH 9.0
#define SSL_RADIUS 8.0
#define GI_TAPS 16
#define GI_STRENGTH 2.0
#define GI_RADIUS 5.0
#define DOF_TAPS 2
#define DOF_STRENGTH 1.2
#define DOF_RADIUS 0.01
#define MB_STRENGTH 0.6
#define MB_MAX 0.03
#define BLOOM_TAPS 16
#define BLOOM_STRENGTH 0.35
#define BLOOM_RADIUS 0.03
#define BLOOM_THRESH 3.0
#define GODRAYS
#define GODRAY_STEPS 20
#define GODRAY_STRENGTH 0.3
#define EXPOSURE 0.36
#define AUTO_EXPOSURE
#define SAT 0.95
#define VIBRANCE 0.08
#define CONTRAST 0.45
#define VIGN 1.1
#define SHADOW_TINT vec3(1.0)
#define HIGH_TINT vec3(1.0)
#define GRADE_AMT 0.0
#define LIFT 0.0
#define LIFT_COL vec3(0.2, 0.18, 0.2)
#define GRAIN
#define GRAIN_AMT 0.06
#define SHARPEN_ON
#define SHARPEN 0.35
#define FXAA_ON
#define MONO
#define MONO_AMT 1.0
#define MONO_ACCENT
#define GBUF_ON
#ifndef SKY_TINT
#define SKY_TINT vec3(1.0)
#endif
#ifndef CLOUD_OCT
#define CLOUD_OCT 3
#endif
#ifndef SKY_STARS
#define SKY_STARS 1
#endif
varying vec4 starData;
varying vec3 vSunTr;
varying vec3 vAmb;
uniform float viewWidth;
uniform float viewHeight;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float rainStrength;
uniform float frameTimeCounter;
uniform float sunAngle;
uniform int moonPhase;
uniform int worldDay;

const vec3 BR = vec3(5.8e-3, 13.5e-3, 33.1e-3);
const float BM = 0.01;
const vec3 BO = vec3(0.65e-3, 1.881e-3, 0.085e-3);
vec3 twilightFill(float h, float cs, float sh) {
    float e = (sh + 0.06) / 0.10;
    float tw = exp(-e * e);
    float side = 0.35 + 0.65 * pow(max(cs, 0.0), 2.0);
    float hz = pow(1.0 - clamp(abs(h), 0.0, 1.0), 3.0);
    vec3 c = mix(vec3(0.07, 0.1, 0.28), vec3(0.95, 0.38, 0.48), hz * side);
    return c * tw * 0.35;
}
vec3 sunTrans(float sh) {
    if (sh < 0.0) return vec3(0.0);
    float R = 6371.0;
    float alt0 = 0.002;
    float sx = sqrt(max(1.0 - sh * sh, 0.0));
    float b = (R + alt0) * sh;
    float tl = -b + sqrt(b * b + (100.0 - alt0) * (2.0 * R + 100.0 + alt0));
    float odr = 0.0; float odm = 0.0; float odo = 0.0;
    for (int j = 0; j < 8; j++) {
        float u = (float(j) + 0.5) / 8.0;
        float d = tl * u * u;
        float w = tl * 2.0 * u / 8.0;
        vec3 Q = vec3(sx * d, R + alt0 + sh * d, 0.0);
        float a = max(length(Q) - R, 0.0);
        odr += exp(-a / 8.0) * w;
        odm += exp(-a / 1.2) * w;
        odo += max(0.0, 1.0 - abs(a - 25.0) / 15.0) * w;
    }
    return exp(-(BR * odr + BM * 1.1 * odm + BO * odo));
}
float effSh(float sh) {
    return sh < 0.0 ? sh : mix(sh * 0.08, sh, smoothstep(0.30, 0.75, sh));
}
float goldF(float shR) {
    return (1.0 - smoothstep(0.15, 0.6, shR)) * smoothstep(-0.05, 0.08, shR);
}
vec3 goldTint(float shR) {
    return mix(vec3(1.0), vec3(1.12, 0.92, 0.64), goldF(shR));
}
vec3 goldenFill(float h, float cs, float shR) {
    float gw = smoothstep(0.0, 0.08, shR) * (1.0 - smoothstep(0.15, 0.6, shR)) * 2.0;
    float hz = pow(1.0 - clamp(abs(h), 0.0, 1.0), 3.0);
    vec3 c = mix(vec3(0.34, 0.16, 0.09), vec3(1.7, 0.75, 0.3), hz);
    return c * gw * (0.4 + 0.6 * pow(max(cs, 0.0), 2.0));
}
vec3 sunLight(float shR) {
    float g = goldF(shR);
    vec3 neutral = sunTrans(shR) * 3.4;
    vec3 golden = vec3(3.4, 1.05, 0.32) * smoothstep(0.0, 0.06, shR);
    return mix(neutral, golden, g);
}

vec3 skyQ(vec3 dir, vec3 sunDir, vec3 upN) {
    float shR = dot(sunDir, upN);
    if (shR < -0.32) return vec3(0.0);
    float sh = effSh(shR);
    float h = max(dot(dir, upN), 0.0005);
    float cs = clamp(dot(dir, sunDir), -1.0, 1.0);
    float vx = sqrt(max(1.0 - h * h, 0.0));
    float sx = (cs - h * sh) / max(vx, 0.0001);
    float sz = sqrt(max(1.0 - sh * sh - sx * sx, 0.0));
    float R = 6371.0;
    float alt0 = 0.002;
    float b = (R + alt0) * h;
    float tm = min(-b + sqrt(b * b + (100.0 - alt0) * (2.0 * R + 100.0 + alt0)), 40.0);
    float ds = tm / float(10);
    float odr = 0.0; float odm = 0.0; float odo = 0.0;
    vec3 sc = vec3(0.0);
    float pr = 0.0596831 * (1.0 + cs * cs) * 1.4;
    float pm = 0.119366 * (0.36 * (1.0 + cs * cs)) / (2.64 * pow(1.64 - 1.6 * cs, 1.5));
    for (int i = 0; i < 10; i++) {
        float t = ds * (float(i) + 0.5);
        float px = vx * t;
        float py = R + alt0 + h * t;
        float len = sqrt(px * px + py * py);
        float alt = (px * px + (alt0 + h * t) * (2.0 * R + alt0 + h * t)) / (len + R);
        float dr = exp(-alt / 8.0);
        float dm = exp(-alt / 1.2);
        float dzo = max(0.0, 1.0 - abs(alt - 25.0) / 15.0);
        odr += dr * ds; odm += dm * ds; odo += dzo * ds;
        float b2 = px * sx + py * sh;
        if (b2 < 0.0 && b2 * b2 - alt * (len + R) > 0.0) continue;
        float tl = -b2 + sqrt(max(b2 * b2 - (alt - 100.0) * (len + 6471.0), 0.0));
        float lr = 0.0; float lm = 0.0; float lo = 0.0;
        for (int j = 0; j < 4; j++) {
            float u = (float(j) + 0.5) / float(4);
            float d = tl * u * u;
            float w = tl * 2.0 * u / float(4);
            vec3 Q = vec3(px + sx * d, py + sh * d, sz * d);
            float a = max(length(Q) - R, 0.0);
            lr += exp(-a / 8.0) * w;
            lm += exp(-a / 1.2) * w;
            lo += max(0.0, 1.0 - abs(a - 25.0) / 15.0) * w;
        }
        vec3 att = exp(-(BR * (odr + lr) + BM * 1.1 * (odm + lm) + BO * (odo + lo)));
        sc += att * (BR * dr * pr + BM * dm * pm) * ds;
    }
    vec3 outc = (sc * 22.0 + twilightFill(h, cs, shR) + goldenFill(h, cs, shR)) * goldTint(shR);
    outc.g = min(outc.g, max(outc.r, outc.b) * 1.04);
    return outc * SKY_TINT;
}


float hash21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vnoise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash21(i), hash21(i + vec2(1.0, 0.0)), f.x),
               mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), f.x), f.y);
}
float fbm4(vec2 p) {
    float a = 0.5; float s = 0.0;
    for (int i = 0; i < 4; i++) { s += a * vnoise(p); p = p * 2.02 + 3.7; a *= 0.5; }
    return s;
}
float fbmC(vec2 p) {
    float a = 0.5; float s = 0.0;
    for (int i = 0; i < CLOUD_OCT; i++) { s += a * vnoise(p); p = p * 2.03 + 1.9; a *= 0.5; }
    return s;
}
float h31(vec3 p) { p = fract(p * 0.1031); p += dot(p, p.yzx + 33.33); return fract((p.x + p.y) * p.z); }
vec3 starField(vec3 d) {
    vec3 q = d * 80.0;
    vec3 id = floor(q);
    vec3 f = fract(q) - 0.5;
    float r = h31(id);
    vec3 off = vec3(h31(id + 11.1), h31(id + 23.7), h31(id + 37.3)) - 0.5;
    float s = smoothstep(0.14, 0.0, length(f - off * 0.7)) * step(0.93, r);
    vec3 tint = mix(vec3(0.7, 0.8, 1.0), vec3(1.0, 0.85, 0.7), h31(id + 5.5));
    return tint * s * (1.5 + 3.0 * fract(r * 13.7));
}
vec3 rotAxis(vec3 v, vec3 k, float a) {
    return v * cos(a) + cross(k, v) * sin(a) + k * dot(k, v) * (1.0 - cos(a));
}
vec3 aurora(vec3 d, float t) {
    if (d.y < 0.02) return vec3(0.0);
    vec3 acc = vec3(0.0);
    for (int i = 0; i < 6; i++) {
        float fi = float(i);
        vec2 p = d.xz / (d.y + 0.25) * (0.8 + fi * 0.18);
        float wob = vnoise(vec2(p.x * 0.5 + t * 0.03, fi * 3.1)) * 3.0;
        float v = p.y * 0.9 + wob;
        float qq = fract(v) - 0.5;
        float rib = exp(-qq * qq * 60.0);
        float flick = 0.6 + 0.4 * vnoise(vec2(p.x * 1.3 - t * 0.15, fi));
        vec3 c = mix(vec3(0.15, 1.0, 0.45), vec3(0.45, 0.3, 1.0), clamp(fi / 5.0 * 0.9 + wob * 0.03, 0.0, 1.0));
        acc += c * rib * flick * (1.0 - fi * 0.1);
    }
    float fade = smoothstep(0.02, 0.3, d.y) * (1.0 - smoothstep(0.55, 0.95, d.y) * 0.6);
    return acc * 0.35 * fade;
}

void main() {
    if (starData.a > 0.5) discard;
    vec4 p = vec4(gl_FragCoord.xy / vec2(viewWidth, viewHeight) * 2.0 - 1.0, 1.0, 1.0);
    p = gbufferProjectionInverse * p;
    vec3 dir = normalize(p.xyz / p.w);
    vec3 upN = normalize(upPosition);
    vec3 sunDir = normalize(sunPosition);
    vec3 wdir = mat3(gbufferModelViewInverse) * dir;
    float h = dot(dir, upN);
    float sunH = dot(sunDir, upN);
    float day = smoothstep(-0.14, 0.12, sunH);
    float nightF = 1.0 - smoothstep(-0.2, 0.02, sunH);
    float rain = rainStrength;
    float gm = smoothstep(-0.015, 0.02, h);
    float sd = dot(dir, sunDir);

    vec3 dq = h < 0.0 ? normalize(dir - 2.0 * h * upN) : dir;
    vec3 col = skyQ(dq, sunDir, upN);
    col *= mix(1.0, 0.55, smoothstep(0.0, -0.3, h));
    col += vec3(0.004, 0.006, 0.013) * nightF * (0.6 + 0.8 * pow(1.0 - clamp(abs(h), 0.0, 1.0), 3.0));

#if SKY_STARS > 0
    {
        vec3 k = normalize(vec3(0.0, -0.42, 0.91));
        vec3 sdir = rotAxis(wdir, k, -sunAngle * 6.2831853);
        float tw = 0.85 + 0.15 * sin(frameTimeCounter * 3.0 + h31(floor(sdir * 80.0)) * 40.0);
        vec3 st = starField(sdir) * tw * nightF * (1.0 - rain) * smoothstep(-0.05, 0.2, h);
        col += st;
#if SKY_STARS > 1
        float band = exp(-pow(abs(dot(sdir, normalize(vec3(0.3, 0.8, 0.5)))) * 3.0, 2.0));
        float dust = fbm4(sdir.xy * 5.0 + sdir.z * 3.1);
        float neb = fbm4(sdir.xy * 2.5 + sdir.z * 1.7);
        col += vec3(0.55, 0.6, 0.85) * band * (0.25 + neb) * (1.1 - dust) * 0.12 * nightF * (1.0 - rain) * gm;
#endif
    }
#endif

#if SKY_STARS > 1
    {
        float mt = frameTimeCounter / 40.0;
        float mid = floor(mt);
        float mf = fract(mt);
        float r1 = fract(sin(mid * 12.9898) * 43758.5453);
        float r2 = fract(sin(mid * 78.233) * 12345.6789);
        float r3 = fract(sin(mid * 39.346) * 5821.3);
        float r4 = fract(sin(mid * 93.989) * 9421.1);
        if (mf < 0.03 && r1 > 0.5) {
            vec3 m0 = normalize(vec3(r1 - 0.5, 0.35 + 0.5 * r2, r3 - 0.5));
            vec3 tdir = normalize(cross(m0, vec3(r4 - 0.5, 0.2, r2 - 0.5)));
            float pr = mf / 0.03;
            vec3 head = normalize(m0 + tdir * pr * 0.45);
            vec3 tail = normalize(m0 + tdir * max(pr - 0.3, 0.0) * 0.45);
            vec3 ba = head - tail;
            float tt = clamp(dot(wdir - tail, ba) / max(dot(ba, ba), 0.000001), 0.0, 1.0);
            float dd = length(wdir - tail - ba * tt);
            col += vec3(1.0, 0.95, 0.85) * exp(-(dd * dd) / 0.00000144) * (0.2 + 0.8 * tt) * 5.0 * nightF * (1.0 - rain) * smoothstep(0.05, 0.2, h);
        }
    }
#endif
#if SKY_AURORA > 0
    float aOn = step(0.62, fract(sin(float(worldDay) * 12.9898) * 43758.5453));
    col += aurora(wdir, frameTimeCounter) * 0.55 * aOn * nightF * (1.0 - rain);
#endif

#if SKY_CLOUDS > 0
    if (wdir.y > 0.0) {
        vec2 wind = vec2(frameTimeCounter * 0.010, frameTimeCounter * 0.004);
#if SKY_CIRRUS > 0
        {
            vec2 cp2 = wdir.xz / (wdir.y + 0.25) * vec2(0.9, 0.32) + wind * 0.5;
            float ci = smoothstep(0.52, 0.8, fbm4(cp2 * vec2(3.0, 1.2)));
            ci *= 0.45 * (1.0 - 0.7 * rain) * smoothstep(0.03, 0.3, wdir.y);
            vec3 cic = vSunTr * 1.4 + vAmb * 0.8;
            col = col * (1.0 - ci) + cic * ci;
            float hq = (acos(clamp(sd, -1.0, 1.0)) - 0.384) / 0.02;
            col += vSunTr * exp(-hq * hq) * ci * 2.0 * (1.0 - rain);
        }
#endif
#if CLOUD_OCT >= 4
        {
            vec2 cp2 = wdir.xz / (wdir.y + 0.14) * 0.42 + wind * 1.7 + 7.3;
            float d2l = smoothstep(mix(0.52, 0.34, rain), mix(0.52, 0.34, rain) + 0.28, fbm4(cp2)) * 0.65;
            vec3 c2 = ((vAmb + vSunTr * 0.25) * 1.1 + vSunTr * 1.5) * mix(1.0, 0.55, rain);
            col = mix(col, c2, d2l * smoothstep(0.02, 0.25, wdir.y));
        }
#endif
        vec2 cp = wdir.xz / (wdir.y + 0.08) * 0.55 + wind;
        float cov = mix(0.34, 0.22, rain);
        vec2 warp = vec2(vnoise(cp * 1.7 + 3.1), vnoise(cp * 1.7 + 9.7)) * 0.25;
        float n = fbmC(cp + warp);
        float dens = smoothstep(cov, cov + 0.26, n);
        if (dens > 0.002) {
            vec3 sunW = mat3(gbufferModelViewInverse) * sunDir;
            vec2 so = sunW.xz * 0.12;
            float n1 = fbmC(cp + warp + so);
            float n2 = fbmC(cp + warp + so * 2.5);
            float od = (max(n1 - cov, 0.0) + max(n2 - cov, 0.0)) * 3.0;
            float Tl = exp(-od * 5.0);
            float thick = max(n - cov, 0.0);
            float powder = 1.0 - 0.6 * exp(-thick * 12.0);
            float hgF = 0.36 / pow(1.64 - 1.6 * max(sd, 0.0), 1.5);
            vec3 sunL = vSunTr * 3.0 * Tl * powder * (0.30 + 0.02 * hgF);
            vec3 ambL = (vAmb * 0.5 + vSunTr * 0.45) * (1.0 - 0.55 * clamp(thick * 3.0, 0.0, 1.0));
            vec3 cc = (ambL + sunL) * 0.9;
            cc *= mix(1.0, 0.55, rain);
            float fadeH = smoothstep(0.015, 0.2, wdir.y);
            col = mix(col, cc, dens * fadeH * 0.95);
        }
    }
#endif

    // overcast in rain
    {
        float lum = dot(col, vec3(0.333));
        col = mix(col, vec3(lum) * vec3(0.85, 0.9, 1.0) * 0.75 + vAmb * 0.25, rain * 0.85);
    }
#if SKY_VIVID > 0
    {
        float l = dot(col, vec3(0.333));
        col = mix(vec3(l), col, 1.2);
    }
#endif
    gl_FragData[0] = vec4(col, 1.0);
}
